// Shared helpers for agent-authored narrative-threshold packs (8b).
//
// Every such pack is committed as `pending_review` and every criterion traces to a real
// source.section + url. These helpers keep that boilerplate consistent and make the
// "no fabrication" boundary explicit: thresholds that cannot be expressed deterministically
// are recorded as NEEDS_HUMAN notes (committed + diff-able) and kept OUT of active checks.
//
// Source-agnostic: works for CMS LCDs (Medicare) and commercial payer policies (Aetna,
// Cigna, ...). The only thing that changes per payer is the SourceRef issuer/doc_type/url.

import { Criterion, PolicyVersion, SourceRef, VersionStatus } from "../types.js";

/** CMS LCD source builder (Medicare). */
export function lcdSource(lcdId: string, lcdNumeric: number): (section: string) => SourceRef {
  const url = `https://www.cms.gov/medicare-coverage-database/view/lcd.aspx?lcdid=${lcdNumeric}`;
  return (section: string): SourceRef => ({ issuer: "CMS", doc_type: "LCD", doc_id: lcdId, section, url });
}

/** Generic source builder for any issuer/document (e.g. a commercial payer policy PDF). */
export function docSource(issuer: string, docType: SourceRef["doc_type"], docId: string, url: string): (section: string) => SourceRef {
  return (section: string): SourceRef => ({ issuer, doc_type: docType, doc_id: docId, section, url });
}

/** A requirement that is real but NOT deterministically expressible — left out of active checks. */
export interface NeedsHuman {
  description: string;
  section: string;
  quote: string;
}

export interface BuildPackArgs {
  version_id: string;
  payer?: string; // default "medicare"
  category: string;
  items: string[];
  jurisdiction?: string;
  effective_date: string;
  title: string;
  criteria: Criterion[];
  needsHuman: NeedsHuman[];
  // Provenance for the version-level source. Either give CMS LCD coordinates...
  lcdId?: string;
  lcdNumeric?: number;
  // ...or a fully explicit source (commercial payers, NCDs, articles, etc.).
  issuer?: string;
  docType?: SourceRef["doc_type"];
  docId?: string;
  url?: string;
  topSection?: string; // version-level source.section label
  status?: VersionStatus; // default "pending_review"; the verified golden pack ships "active"
  createdBy?: string; // default "agent-authored:8b"
}

/** Assemble a pending_review PolicyVersion from authored criteria + NEEDS_HUMAN notes. */
export function buildPack(a: BuildPackArgs): PolicyVersion {
  const issuer = a.issuer ?? "CMS";
  const docType = a.docType ?? "LCD";
  const docId = a.docId ?? a.lcdId ?? "UNKNOWN";
  const url = a.url ?? (a.lcdNumeric != null ? `https://www.cms.gov/medicare-coverage-database/view/lcd.aspx?lcdid=${a.lcdNumeric}` : "");
  const section = a.topSection ?? "Coverage Indications, Limitations, and/or Medical Necessity";
  const nh =
    a.needsHuman.length > 0
      ? ` ${a.needsHuman.length} requirement(s) could not be expressed deterministically and are recorded as [NEEDS_HUMAN] notes (excluded from checks).`
      : "";
  return {
    version_id: a.version_id,
    key: { payer: a.payer ?? "medicare", category: a.category, items: a.items, jurisdiction: a.jurisdiction ?? "national" },
    status: a.status ?? "pending_review", // agent-authored default; verified golden pack = "active"
    effective_date: a.effective_date,
    criteria: a.criteria,
    source: { issuer, doc_type: docType, doc_id: docId, section, url },
    created_at: "2026-06-15T00:00:00Z",
    created_by: a.createdBy ?? "agent-authored:8b",
    notes: `Clinical thresholds authored from the narrative of ${a.title} (${docId}). Pending human review against the source.${nh}`,
  };
}
