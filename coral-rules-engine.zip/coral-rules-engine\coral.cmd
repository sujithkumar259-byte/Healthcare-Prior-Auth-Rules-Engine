@echo off
REM Convenience launcher: puts the bundled portable Node on PATH, then runs an npm script.
REM Usage from this folder:  coral demo  |  coral test  |  coral ingest -- L33718
set "PATH=%~dp0.toolchain\node-v24.16.0-win-x64;%PATH%"
npm run %*
