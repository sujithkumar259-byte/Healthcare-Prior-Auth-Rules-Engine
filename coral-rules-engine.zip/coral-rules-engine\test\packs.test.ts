// Acceptance 6: every Criterion in every produced version has a non-empty source.doc_id + url.
// Acceptance 7: every agent-authored pack is committed as pending_review, each criterion
//   traces to a real source.section + url, and the build contains NO LLM/SDK import and no
//   network call to a model endpoint.
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { dirname } from "node:path";
import { test, eq, ok, section } from "./harness.js";
import { allPacks, loadActivePacks, loadPendingPacks } from "../src/packs/registry.js";
import { validateCheck } from "../src/dsl-validate.js";
import { InMemoryPolicyStore, ReviewQueue } from "../src/store.js";
import { evaluateCase } from "../src/engine.js";
import { Case } from "../src/types.js";

const here = dirname(fileURLToPath(import.meta.url));
const ROOT = join(here, "..");

function allSourceFiles(dir: string, acc: string[] = []): string[] {
  for (const name of readdirSync(dir)) {
    if (name === "node_modules" || name === ".toolchain" || name === "dist" || name === ".lcd-cache" || name.startsWith(".git")) continue;
    const p = join(dir, name);
    const s = statSync(p);
    if (s.isDirectory()) allSourceFiles(p, acc);
    else if (name.endsWith(".ts") || name.endsWith(".json")) acc.push(p);
  }
  return acc;
}

export function packsTests(): void {
  section("Authored packs (Acceptance 6, 7)");

  test("no pack ships active — every pack is pending_review until a clinician approves it", () => {
    const active = loadActivePacks();
    eq(active.length, 0, "no packs active — all require clinician approval");
    const pending = loadPendingPacks();
    eq(pending.length, allPacks().length, "every loaded pack is pending_review");
    // The verified seed PAP pack is created_by "seed:verified"; all others are agent-authored.
    for (const v of pending) ok(/^(agent-authored|seed:verified)/.test(v.created_by), `${v.version_id} created_by ${v.created_by}`);
  });

  test("every criterion in every pack has source.doc_id + source.section + http url (Acceptance 6/7)", () => {
    for (const v of allPacks()) {
      for (const c of v.criteria) {
        ok(c.source.doc_id.length > 0, `${v.version_id}/${c.id} doc_id`);
        ok(!!c.source.section && c.source.section.length > 0, `${v.version_id}/${c.id} section`);
        ok(c.source.url.startsWith("http"), `${v.version_id}/${c.id} url`);
      }
    }
  });

  test("every check in every pack is structurally valid (no malformed generated data)", () => {
    for (const v of allPacks()) {
      for (const c of v.criteria) {
        const errs = validateCheck(c.check);
        ok(errs.length === 0, `${v.version_id}/${c.id}: ${errs.join("; ")}`);
      }
    }
  });

  test("all version ids and category keys are unique across packs", () => {
    const ids = allPacks().map((v) => v.version_id);
    eq(ids.length, new Set(ids).size, "duplicate version_id");
  });

  test("pending authored packs do NOT resolve until approved; approval activates them", () => {
    const store = new InMemoryPolicyStore();
    // clone so activating in this test does not mutate the shared module-level pack objects
    allPacks().forEach((v) => store.upsert(structuredClone(v)));
    const review = new ReviewQueue(store);

    const oxyCase: Case = {
      case_id: "OX", service_date: "2026-01-01", category: "home_oxygen", phase: "initial",
      coverage: { payer: "medicare", jurisdiction: "national" },
      order: { items: ["E1390"], dx: ["J96.11"] },
      evidence: { "oxygen.rest.pao2_mmhg": { value: 52, confidence: 0.95 } },
    };
    eq(evaluateCase(oxyCase, store.resolve(oxyCase)).verdict, "no_policy", "pending pack not resolvable");

    const oxy = store.pending().find((v) => v.key.category === "home_oxygen")!;
    review.approve(oxy.version_id, "sujith");
    const v = evaluateCase(oxyCase, store.resolve(oxyCase));
    eq(v.verdict, "submit_ready", "PaO2 52 <= 55 qualifies once active");
  });

  test("authored pack evaluates an unmet case to needs_info", () => {
    const store = new InMemoryPolicyStore();
    allPacks().forEach((v) => store.upsert(structuredClone(v)));
    new ReviewQueue(store).approve(store.pending().find((v) => v.key.category === "home_oxygen")!.version_id, "sujith");
    const c: Case = {
      case_id: "OX2", service_date: "2026-01-01", category: "home_oxygen", phase: "initial",
      coverage: { payer: "medicare", jurisdiction: "national" },
      order: { items: ["E1390"], dx: ["J96.11"] },
      evidence: { "oxygen.rest.pao2_mmhg": { value: 70, confidence: 0.95 } }, // does not qualify
    };
    eq(evaluateCase(c, store.resolve(c)).verdict, "needs_info");
  });

  section("No runtime LLM (Acceptance 7)");

  test("no source file imports an LLM/model SDK or calls a model endpoint", () => {
    const forbidden = [
      /@anthropic-ai/i,
      /from\s+['"]openai['"]/i,
      /require\(\s*['"]openai['"]\s*\)/i,
      /api\.anthropic\.com/i,
      /api\.openai\.com/i,
      /generativelanguage\.googleapis/i,
      /\bextractCriteria\b/, // the LLM-extraction function from the reference must not exist
    ];
    const files = allSourceFiles(join(ROOT, "src")).concat(allSourceFiles(join(ROOT, "scripts")));
    for (const f of files) {
      const text = readFileSync(f, "utf8");
      for (const re of forbidden) ok(!re.test(text), `${f} must not match ${re}`);
    }
  });

  test("package.json declares no LLM SDK dependency", () => {
    const pkg = JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8"));
    const deps = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
    for (const name of Object.keys(deps)) {
      ok(!/anthropic|openai|cohere|@google\/generative|mistral/i.test(name), `unexpected LLM dep: ${name}`);
    }
  });
}
