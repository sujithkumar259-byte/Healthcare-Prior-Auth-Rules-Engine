// Engine core: turn (case, policy version) into a Verdict.
//
// Deterministic and side-effect free. The only "judgment call" is abstention: when a
// required field was extracted below the confidence threshold, the engine routes to a
// human (uncertain) instead of asserting a result it cannot stand behind.

import { Case, Criterion, CriterionResult, PolicyVersion, Verdict } from "./types.js";
import { evalCheck, isPresent, resolveConfidence } from "./dsl.js";

export const DEFAULT_TAU = 0.85; // confidence threshold; per-payer override possible

/**
 * Evaluate one criterion:
 *   1. present := every path in `requires` resolves to a non-null value.
 *   2. conf    := min confidence over `requires` paths (1 where unspecified).
 *   3. status  := not present -> "missing"
 *                 present but conf < tau -> "uncertain"  (abstain, don't assert)
 *                 else evalCheck -> "satisfied" | "unmet"
 *   4. gap_action := criterion.gap[status] when not satisfied.
 */
export function evaluateCriterion(c: Case, cr: Criterion, tau = DEFAULT_TAU): CriterionResult {
  const present = cr.requires.every((p) => isPresent(c, p));
  const conf = cr.requires.length ? Math.min(...cr.requires.map((p) => resolveConfidence(c, p))) : 1;

  let status: CriterionResult["status"];
  if (!present) status = "missing";
  else if (conf < tau) status = "uncertain";
  else status = evalCheck(c, cr.check) ? "satisfied" : "unmet";

  return {
    criterion_id: cr.id,
    description: cr.description,
    status,
    confidence: present ? conf : null,
    gap_action: status === "satisfied" ? undefined : cr.gap[status],
    source: cr.source,
  };
}

/**
 * Evaluate a whole case against the resolved policy version.
 *
 *   - No version              -> "no_policy".
 *   - Evaluate only criteria whose phase is unset or equals case.phase.
 *   - Verdict rollup (hard criteria drive it):
 *        any hard missing|unmet   -> "needs_info"
 *        else any hard uncertain  -> "abstain"
 *        else                     -> "submit_ready"
 *
 * Soft criteria still appear in `results` (with gap actions) but never change the verdict.
 */
export function evaluateCase(c: Case, version: PolicyVersion | null, tau = DEFAULT_TAU): Verdict {
  if (!version) {
    return { case_id: c.case_id, policy_version_id: null, results: [], verdict: "no_policy" };
  }

  const applicable = version.criteria.filter((cr) => !cr.phase || cr.phase === c.phase);
  const results = applicable.map((cr) => evaluateCriterion(c, cr, tau));

  const hardIds = new Set(applicable.filter((cr) => cr.hard).map((cr) => cr.id));
  const anyHard = (statuses: CriterionResult["status"][]) =>
    results.some((r) => hardIds.has(r.criterion_id) && statuses.includes(r.status));

  const verdict: Verdict["verdict"] = anyHard(["missing", "unmet"])
    ? "needs_info"
    : anyHard(["uncertain"])
      ? "abstain"
      : "submit_ready";

  return { case_id: c.case_id, policy_version_id: version.version_id, results, verdict };
}
