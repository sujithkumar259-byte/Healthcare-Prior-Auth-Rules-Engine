// Policy registry: stores versions, resolves the one in force on a service date, and
// gates activation behind human review. `PolicyStore` is an interface so a Postgres
// (or other) backing store can drop in later; v1 ships InMemoryPolicyStore.

import { Case, PolicyKey, PolicyVersion } from "./types.js";

/** Item overlap: an empty policy item-set matches any order. */
const itemsOverlap = (policyItems: string[], orderItems: string[]) =>
  policyItems.length === 0 || policyItems.some((x) => orderItems.includes(x));

export interface PolicyStore {
  upsert(v: PolicyVersion): void;
  /** Activate a pending/draft version and retire the prior active version of the same key. */
  activate(version_id: string, reviewer: string): void;
  /** Send a version back to draft (review rejected). */
  reject(version_id: string): void;
  /** The active version in force on the case's service date, or null. */
  resolve(c: Case): PolicyVersion | null;
  /** All versions matching a partial key, newest effective_date first. */
  history(key: Partial<PolicyKey>): PolicyVersion[];
  /** Versions awaiting human review. */
  pending(): PolicyVersion[];
  get(version_id: string): PolicyVersion | undefined;
}

export class InMemoryPolicyStore implements PolicyStore {
  private versions = new Map<string, PolicyVersion>();

  upsert(v: PolicyVersion): void {
    this.versions.set(v.version_id, v);
  }

  get(version_id: string): PolicyVersion | undefined {
    return this.versions.get(version_id);
  }

  activate(version_id: string, reviewer: string): void {
    const v = this.versions.get(version_id);
    if (!v) throw new Error("version not found: " + version_id);

    // Retire any prior active version of the same key, dating its retirement to the new
    // version's effective date so resolution by service-date stays seamless.
    for (const other of this.versions.values()) {
      if (
        other.version_id !== version_id &&
        other.status === "active" &&
        sameKey(other.key, v.key)
      ) {
        other.status = "retired";
        other.retirement_date = v.effective_date;
      }
    }

    v.status = "active";
    v.created_by = reviewer;
  }

  reject(version_id: string): void {
    const v = this.versions.get(version_id);
    if (v) v.status = "draft";
  }

  resolve(c: Case): PolicyVersion | null {
    // Retirement is DATE-relative: a version applies on a service date if it was effective
    // by then and not yet retired as of then. So a version retired in the future relative to
    // a historical service date is still the one that "applied then" (spec §9). draft /
    // pending_review versions are never resolvable (spec acceptance 5).
    const candidates = [...this.versions.values()].filter(
      (v) =>
        (v.status === "active" || v.status === "retired") &&
        v.key.payer === c.coverage.payer &&
        v.key.category === c.category &&
        itemsOverlap(v.key.items, c.order.items) &&
        // jurisdiction must match when both sides specify one
        (!v.key.jurisdiction || !c.coverage.jurisdiction || v.key.jurisdiction === c.coverage.jurisdiction) &&
        v.effective_date <= c.service_date &&
        // ignore versions retired on or before the service date
        (!v.retirement_date || v.retirement_date > c.service_date),
    );
    // Latest effective date wins (most recent policy in force on that date).
    candidates.sort((a, b) => (a.effective_date < b.effective_date ? 1 : -1));
    return candidates[0] ?? null;
  }

  history(key: Partial<PolicyKey>): PolicyVersion[] {
    return [...this.versions.values()]
      .filter(
        (v) =>
          (!key.payer || v.key.payer === key.payer) &&
          (!key.category || v.key.category === key.category) &&
          (!key.jurisdiction || v.key.jurisdiction === key.jurisdiction),
      )
      .sort((a, b) => (a.effective_date < b.effective_date ? 1 : -1));
  }

  pending(): PolicyVersion[] {
    return [...this.versions.values()].filter((v) => v.status === "pending_review");
  }
}

/** Two keys are "the same policy" iff payer+category+jurisdiction+items all match. */
function sameKey(a: PolicyKey, b: PolicyKey): boolean {
  return (
    a.payer === b.payer &&
    a.category === b.category &&
    a.jurisdiction === b.jurisdiction &&
    a.items.join(",") === b.items.join(",")
  );
}

/**
 * Human review gate. Nothing a connector ingests and nothing an agent authors goes live
 * without passing through here. `approve` activates (and retires the prior); `reject`
 * returns the version to draft.
 */
export class ReviewQueue {
  constructor(private store: PolicyStore) {}

  list(): PolicyVersion[] {
    return this.store.pending();
  }

  approve(version_id: string, reviewer: string): void {
    this.store.activate(version_id, reviewer);
  }

  reject(version_id: string): void {
    this.store.reject(version_id);
  }
}
