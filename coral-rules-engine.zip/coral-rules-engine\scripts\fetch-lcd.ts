// fetch-lcd — print/save an LCD's narrative text so the agent can read the
// "Coverage Indications, Limitations, and/or Medical Necessity" section while authoring
// the clinical-threshold pack (8b). This is a BUILD-TIME helper; it never runs in the engine.
//
//   npm run fetch-lcd -- L33797            (print to stdout)
//   npm run fetch-lcd -- L33797 --save     (also save to .lcd-cache/L33797.txt)
//   npm run fetch-lcd -- L33797 --sections (list section names + lengths only)

import { mkdirSync, writeFileSync } from "node:fs";
import { CmsClient, numericId } from "../src/cms-client.js";

async function main() {
  const args = process.argv.slice(2).filter((a) => a !== "--");
  const lcd = args.find((a) => !a.startsWith("--"));
  if (!lcd) {
    console.error("usage: npm run fetch-lcd -- <LCD id> [--save] [--sections]");
    process.exit(2);
  }
  const client = new CmsClient();

  if (args.includes("--sections")) {
    const d = await client.getLcdDetail(lcd);
    console.log(`# ${d.title}\nLCD ${d.lcd_id} v${d.lcd_version}  effective ${d.effective_date ?? "?"}\n${d.url}\n`);
    for (const [name, text] of Object.entries(d.sections)) {
      console.log(`  - ${name}  (${text.length} chars)`);
    }
    return;
  }

  const text = await client.getLcdText(lcd);
  if (args.includes("--save")) {
    mkdirSync(".lcd-cache", { recursive: true });
    const path = `.lcd-cache/L${numericId(lcd)}.txt`;
    writeFileSync(path, text, "utf8");
    console.error(`saved ${text.length} chars -> ${path}`);
  }
  console.log(text);
}

main().catch((e) => {
  console.error("fetch-lcd failed:", e instanceof Error ? e.message : e);
  process.exit(1);
});
