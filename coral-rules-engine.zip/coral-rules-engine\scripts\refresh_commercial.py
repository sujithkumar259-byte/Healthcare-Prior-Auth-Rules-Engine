"""refresh-commercial — detect which tracked commercial policies (Cigna, Aetna) have
changed at the payer's site, and stage the changed ones for re-authoring + review.

  python scripts/refresh_commercial.py            # check ALL tracked commercial policies
  python scripts/refresh_commercial.py --limit 6  # check first N (for a quick run)
  python scripts/refresh_commercial.py --payer aetna

The CHECK is free (no LLM): it re-fetches each policy, extracts the policy TEXT (so a
regenerated-but-identical PDF/HTML doesn't false-trigger), hashes it, and compares to the
baseline in .lcd-cache/refresh-state.json.

  - first time a policy is seen   -> baseline recorded (no action)
  - text identical to baseline    -> unchanged (skip)
  - text differs                  -> CHANGED: new text saved to .lcd-cache/staged/, listed
                                     in refresh-report.json for re-authoring -> pending_review

Re-authoring the changed list (the only step that costs tokens) is a separate action.
Nothing is auto-approved; a human still approves the re-authored version.
"""
import json, os, re, html, hashlib, subprocess, tempfile, sys

ROOT = r"C:/Users/sp48412/Desktop/Rules Engine"
MAN = os.path.join(ROOT, "src/packs/data/_manifest.json")
STATE = os.path.join(ROOT, ".lcd-cache/refresh-state.json")
STAGED = os.path.join(ROOT, ".lcd-cache/staged")
REPORT = os.path.join(ROOT, "refresh-report.json")
UA = "Mozilla/5.0 (research; policy-ingest)"
os.makedirs(STAGED, exist_ok=True)
TMP = tempfile.gettempdir()

args = sys.argv[1:]
limit = int(args[args.index("--limit") + 1]) if "--limit" in args else None
payer_filter = args[args.index("--payer") + 1] if "--payer" in args else None

def curl(url, outfile):
    r = subprocess.run(["curl", "-sS", "-L", "-m", "60", "-A", UA, "-o", outfile, url],
                       capture_output=True, text=True)
    return r.returncode == 0 and os.path.exists(outfile) and os.path.getsize(outfile) > 0

def extract(path, is_pdf):
    if is_pdf:
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(path).pages)
    raw = open(path, encoding="utf-8", errors="ignore").read()
    raw = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", raw)
    return html.unescape(re.sub(r"(?s)<[^>]+>", " ", raw))

def norm(t):
    # hash the CONTENT, not formatting/regeneration noise
    return re.sub(r"\s+", " ", t).strip().lower()

manifest = json.load(open(MAN))
commercial = [e for e in manifest if e.get("payer") in ("cigna", "aetna") and e.get("url")]
if payer_filter:
    commercial = [e for e in commercial if e["payer"] == payer_filter]
if limit:
    commercial = commercial[:limit]

state = json.load(open(STATE)) if os.path.exists(STATE) else {}
report = {"checked": 0, "new_baseline": 0, "unchanged": 0, "changed": []}
pdf = os.path.join(TMP, "refresh_doc.bin")

for e in commercial:
    key = e["docId"]
    if not curl(e["url"], pdf):
        print(f"  WARN fetch failed: {key}")
        continue
    report["checked"] += 1
    is_pdf = e["url"].lower().endswith(".pdf")
    try:
        h = hashlib.sha256(norm(extract(pdf, is_pdf)).encode("utf-8")).hexdigest()
    except Exception as ex:
        print(f"  WARN extract failed: {key}: {ex}"); continue
    if key not in state:
        state[key] = h; report["new_baseline"] += 1
    elif state[key] == h:
        report["unchanged"] += 1
    else:
        # changed: stage the new text, keep old baseline until re-authored+approved
        ext = "pdf" if is_pdf else "html"
        staged_txt = os.path.join(STAGED, f"{e['category']}.txt")
        open(staged_txt, "w", encoding="utf-8").write(extract(pdf, is_pdf))
        report["changed"].append({"category": e["category"], "docId": key, "url": e["url"],
                                  "old": state[key][:8], "new": h[:8], "staged_text": staged_txt})

json.dump(state, open(STATE, "w"), indent=1)
json.dump(report, open(REPORT, "w"), indent=1)

print(f"refresh-commercial: checked {report['checked']}  "
      f"(baseline {report['new_baseline']}, unchanged {report['unchanged']}, CHANGED {len(report['changed'])})")
for c in report["changed"]:
    print(f"  CHANGED  {c['category']}  ({c['docId']})  {c['old']} -> {c['new']}")
if report["changed"]:
    print(f"\n{len(report['changed'])} policy(ies) changed. Re-author the staged text in .lcd-cache/staged/,")
    print("which loads as a new pending_review version (new content -> new version id), then approve.")
else:
    print("Nothing to re-author." if report["new_baseline"] == 0 else "Baseline established; re-run later to detect changes.")
