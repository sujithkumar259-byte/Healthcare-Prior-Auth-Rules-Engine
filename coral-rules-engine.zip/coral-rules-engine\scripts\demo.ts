// Demo: load the verified PAP pack and evaluate sample cases (Acceptance 1).
//
//   run:  npm run demo
//
//   - Base case (appendix)                          -> submit_ready
//   - benefit_reeval.improved flipped to false      -> needs_info
//   - adherence confidence dropped to 0.6 (< tau)   -> abstain
//   - a payer/category with no policy               -> no_policy

import { InMemoryPolicyStore } from "../src/store.js";
import { evaluateCase } from "../src/engine.js";
import { loadActivePacks } from "../src/packs/registry.js";
import { Case } from "../src/types.js";

const store = new InMemoryPolicyStore();
loadActivePacks().forEach((v) => store.upsert(v)); // the verified golden PAP pack

// Appendix sample case (continued-coverage CPAP for a Medicare beneficiary).
const baseCase: Case = {
  case_id: "PA-3001",
  service_date: "2026-06-11",
  category: "dme_pap",
  phase: "continued",
  coverage: { payer: "medicare", jurisdiction: "national" },
  order: { items: ["E0601"], dx: ["G47.33"], prescriber_npi: "1992001122" },
  evidence: {
    "adherence.nights_used_ge4h": { value: 26, confidence: 0.97 },
    "adherence.total_nights": { value: 30, confidence: 0.97 },
    "benefit_reeval.improved": { value: true, confidence: 0.95 },
  },
};

function run(label: string, c: Case) {
  const version = store.resolve(c);
  const verdict = evaluateCase(c, version);
  console.log(`\n### ${label}`);
  console.log(`resolved version : ${verdict.policy_version_id ?? "(none)"}`);
  console.log(`verdict          : ${verdict.verdict.toUpperCase()}`);
  for (const r of verdict.results) {
    const conf = r.confidence === null ? "n/a" : r.confidence.toFixed(2);
    const gap = r.gap_action ? `  -> ${r.gap_action}` : "";
    console.log(`  [${r.status.padEnd(9)}] ${r.criterion_id} (conf ${conf})${gap}`);
  }
  return verdict;
}

// 1) Base case -> submit_ready
run("Base appendix case", baseCase);

// 2) Re-eval not improved -> needs_info
const notImproved: Case = {
  ...baseCase,
  case_id: "PA-3001-b",
  evidence: { ...baseCase.evidence, "benefit_reeval.improved": { value: false, confidence: 0.95 } },
};
run("benefit_reeval.improved = false", notImproved);

// 3) Low-confidence adherence -> abstain
const lowConf: Case = {
  ...baseCase,
  case_id: "PA-3001-c",
  evidence: { ...baseCase.evidence, "adherence.nights_used_ge4h": { value: 26, confidence: 0.6 } },
};
run("adherence confidence = 0.60", lowConf);

// 4) No matching policy -> no_policy
const noPolicy: Case = {
  ...baseCase,
  case_id: "PA-3001-d",
  category: "dme_pap",
  coverage: { payer: "cigna", jurisdiction: "national" },
};
run("unknown payer (cigna)", noPolicy);

console.log("\n(done)");
