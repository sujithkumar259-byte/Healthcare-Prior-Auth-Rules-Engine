// Tiny zero-dependency test harness. Deterministic, no external test runner.
let passed = 0;
let failed = 0;
const failures: string[] = [];

export function test(name: string, fn: () => void): void {
  try {
    fn();
    passed++;
    console.log(`  ok   ${name}`);
  } catch (e) {
    failed++;
    const msg = e instanceof Error ? e.message : String(e);
    failures.push(`${name}: ${msg}`);
    console.log(`  FAIL ${name}\n       ${msg}`);
  }
}

export function eq(actual: unknown, expected: unknown, msg?: string): void {
  const a = JSON.stringify(actual);
  const b = JSON.stringify(expected);
  if (a !== b) throw new Error(`${msg ?? "equality"}: expected ${b}, got ${a}`);
}

export function ok(cond: unknown, msg?: string): void {
  if (!cond) throw new Error(msg ?? "expected truthy");
}

export function section(name: string): void {
  console.log(`\n# ${name}`);
}

export function summarize(): void {
  console.log(`\n${failed === 0 ? "PASS" : "FAIL"} — ${passed} passed, ${failed} failed`);
  if (failed > 0) {
    console.log(failures.map((f) => " - " + f).join("\n"));
    process.exit(1);
  }
}
