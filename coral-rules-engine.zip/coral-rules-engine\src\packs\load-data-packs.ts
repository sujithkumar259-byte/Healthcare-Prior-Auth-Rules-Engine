// Data-driven pack loader (the scalable path for bulk Medicare-PA categories).
//
// `src/packs/data/_manifest.json` lists every target category (LCD id, title, effective date,
// HCPCS items — fetched live from CMS). Each `src/packs/data/<category>.json` holds the
// agent-authored criteria (with verbatim grounding) for that category. This loader pairs them,
// validates every check structurally, and emits pending_review PolicyVersions.
//
// Rules are DATA: adding a category is a new JSON file + a manifest row — no code change.

import { readFileSync, existsSync } from "node:fs";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { Criterion, PolicyVersion, SourceRef } from "../types.js";
import { buildPack, docSource, lcdSource, NeedsHuman } from "./_pack-helpers.js";
import { assertValidCheck } from "../dsl-validate.js";

const DATA_DIR = join(dirname(fileURLToPath(import.meta.url)), "data");

interface ManifestEntry {
  category: string;
  title: string;
  effective_date: string | null;
  items: string[];
  // Medicare LCD coordinates (default issuer CMS / doc_type LCD)...
  lcdId?: string;
  lcdNumeric?: number;
  version?: number;
  // ...or an explicit non-CMS source (commercial payers etc.).
  payer?: string;
  jurisdiction?: string;
  issuer?: string;
  docType?: SourceRef["doc_type"];
  docId?: string;
  url?: string;
  status?: PolicyVersion["status"]; // default pending_review; golden pack = active
  createdBy?: string;
}

interface AuthoredCriterion {
  id: string;
  phase?: "initial" | "continued" | null;
  hard: boolean;
  description: string;
  check: unknown;
  requires?: string[];
  gap?: Partial<Record<"missing" | "unmet" | "uncertain", string>>;
  section?: string;
  quote?: string; // verbatim grounding, kept for the human reviewer
  source?: SourceRef; // optional full source override (e.g. a pack citing multiple documents)
}

interface AuthoredPack {
  category: string;
  criteria: AuthoredCriterion[];
  needsHuman?: NeedsHuman[];
}

function readManifest(): ManifestEntry[] {
  const p = join(DATA_DIR, "_manifest.json");
  if (!existsSync(p)) return [];
  return JSON.parse(readFileSync(p, "utf8")) as ManifestEntry[];
}

/** Parse/validation problems encountered the last time loadDataPacks() ran. */
export const dataPackErrors: string[] = [];

/**
 * Build pending_review PolicyVersions from every authored data pack present on disk.
 * Categories listed in the manifest but not yet authored (no JSON file) are skipped, so
 * partial progress loads cleanly. A file that fails to parse or validate is skipped and
 * recorded in `dataPackErrors` (a test asserts that list is empty) — one bad file never
 * corrupts the whole registry, but the failure is never silent.
 */
export function loadDataPacks(): PolicyVersion[] {
  dataPackErrors.length = 0;
  const out: PolicyVersion[] = [];
  for (const m of readManifest()) {
    const file = join(DATA_DIR, `${m.category}.json`);
    if (!existsSync(file)) continue;
    try {
      const authored = JSON.parse(readFileSync(file, "utf8")) as AuthoredPack;
      // Per-criterion source builder: CMS LCD by default, or an explicit payer source.
      const src =
        m.lcdId != null && m.lcdNumeric != null && !m.url
          ? lcdSource(m.lcdId, m.lcdNumeric)
          : docSource(m.issuer ?? "CMS", m.docType ?? "LCD", m.docId ?? m.lcdId ?? m.category, m.url ?? "");
      const criteria: Criterion[] = authored.criteria.map((a) => {
        assertValidCheck(a.check, `${m.category}/${a.id}`); // throws on malformed data
        // A criterion may carry a full source override (multi-document packs); otherwise it
        // uses its section against the manifest-derived source.
        let crSource: SourceRef;
        if (a.source && a.source.doc_id && a.source.url) crSource = a.source;
        else if (a.section) crSource = src(a.section);
        else throw new Error(`${m.category}/${a.id}: missing source section or source override`);
        const phase = a.phase ?? undefined;
        const crit: Criterion = {
          id: a.id,
          hard: a.hard,
          description: a.description,
          check: a.check as Criterion["check"],
          requires: a.requires ?? [],
          gap: a.gap ?? {},
          source: crSource,
        };
        if (phase) crit.phase = phase;
        return crit;
      });
      const payer = m.payer ?? "medicare";
      const docId = m.docId ?? m.lcdId ?? m.category;
      // Content-hash the authored rules. The version_id carries the hash so that when a
      // policy is re-authored after a payer update, the new content produces a NEW version
      // id (it appends alongside the old one — history preserved — rather than silently
      // overwriting it). Unchanged content => identical id => idempotent reloads.
      const contentHash = createHash("sha256").update(JSON.stringify(authored.criteria)).digest("hex");
      const v = buildPack({
        version_id: `${payer}-${m.category}-${docId}-${contentHash.slice(0, 8)}`,
        payer,
        category: m.category,
        items: m.items ?? [],
        jurisdiction: m.jurisdiction,
        effective_date: m.effective_date ?? new Date().toISOString().slice(0, 10),
        lcdId: m.lcdId,
        lcdNumeric: m.lcdNumeric,
        issuer: m.issuer,
        docType: m.docType,
        docId: m.docId,
        url: m.url,
        title: m.title,
        status: m.status,
        createdBy: m.createdBy,
        criteria,
        needsHuman: authored.needsHuman ?? [],
      });
      v.source.checksum = contentHash;
      out.push(v);
    } catch (e) {
      dataPackErrors.push(`${m.category} (${m.lcdId}): ${e instanceof Error ? e.message : String(e)}`);
    }
  }
  return out;
}

/** Categories declared in the manifest (whether or not authored yet). */
export function manifestCategories(): ManifestEntry[] {
  return readManifest();
}
