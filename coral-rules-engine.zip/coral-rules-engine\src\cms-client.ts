// CMS Medicare Coverage Database client.
//
// Real API, base https://api.coverage.cms.gov, no API key. LCD/Article *data* endpoints
// require a short-lived Bearer token obtained by accepting the license agreement
// (AMA CPT / ADA CDT / AHA NUBC); the token is valid ~1 hour.
//
// The published swagger is a stub (no paths), so endpoint shapes below were confirmed by
// probing the live API. Everything is parsed DEFENSIVELY: responses wrap rows under
// `data`, column names under `meta.fields`, and paginate via `meta.next_token`.
//
// This file makes NO model/LLM calls. It is plain HTTP + JSON.

const BASE = "https://api.coverage.cms.gov";

/** A row from the final-LCDs catalog report. */
export interface LcdCatalogEntry {
  document_id: number;
  document_version: number;
  document_display_id: string; // "L33718"
  document_type: string; // "LCD"
  title: string;
  updated_on: string;
  effective_date: string; // "MM/DD/YYYY"
  retirement_date: string; // "MM/DD/YYYY" or "N/A"
  url: string;
}

export interface HcpcRow {
  hcpc_code_id: string; // "E0601"
  short_description?: string;
  long_description?: string;
  hcpc_code_group?: number;
}

export interface Icd10Row {
  icd10_code_id: string; // "G47.33"
  description?: string;
  group?: number;
}

export interface ModifierRow {
  hcpc_modifier_code_id: string;
  description?: string;
  group?: number;
}

/** Narrative + metadata for one LCD (the source for authoring clinical-threshold packs). */
export interface LcdDetail {
  lcd_id: number;
  lcd_version: number;
  title: string;
  effective_date?: string; // ISO, best-effort from rev/orig dates
  url: string;
  /** Section name -> plain text (HTML stripped). Keyed for the authoring workflow. */
  sections: Record<string, string>;
}

interface ApiResponse {
  meta?: { fields?: string[]; next_token?: string | null; status?: { id?: number; message?: string } };
  data?: any[];
}

/** "L33718" | "l33718" | "33718" | 33718 -> 33718. "A52467" -> 52467. */
export function numericId(displayId: string | number): number {
  if (typeof displayId === "number") return displayId;
  const m = String(displayId).match(/\d+/);
  if (!m) throw new Error(`cannot parse a numeric id from "${displayId}"`);
  return parseInt(m[0], 10);
}

/** CMS "MM/DD/YYYY" -> ISO "YYYY-MM-DD". Returns undefined for "N/A"/blank/unparsable. */
export function toISODate(s: string | undefined | null): string | undefined {
  if (!s) return undefined;
  const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})/);
  if (!m) return undefined;
  return `${m[3]}-${m[1]}-${m[2]}`;
}

/** Decode the (often double-encoded) HTML in narrative fields and strip tags to plain text. */
export function htmlToText(raw: string | null | undefined): string {
  if (!raw) return "";
  let s = String(raw);
  // CMS double-encodes: "&lt;p&gt;" -> "<p>". Decode entities twice, then strip tags.
  const decode = (x: string) =>
    x
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#160;|&nbsp;/g, " ")
      .replace(/&amp;/g, "&");
  s = decode(decode(s));
  s = s.replace(/<\s*br\s*\/?>/gi, "\n").replace(/<\/(p|div|li|tr|h\d)>/gi, "\n");
  s = s.replace(/<[^>]+>/g, ""); // strip remaining tags
  s = s.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  return s;
}

export class CmsClient {
  private token?: string;
  private tokenFetchedAt = 0;
  private readonly tokenTtlMs = 55 * 60 * 1000; // refresh before the ~1h expiry

  constructor(private base: string = BASE) {}

  /** Accept the license agreement and cache the bearer token (~1h). */
  async licenseToken(): Promise<string> {
    const fresh = this.token && Date.now() - this.tokenFetchedAt < this.tokenTtlMs;
    if (fresh) return this.token!;
    const j = await this.getJson(`/v1/metadata/license-agreement`, false);
    const token = j.data?.[0]?.Token ?? j.data?.[0]?.token;
    if (!token) throw new Error("license-agreement response did not contain a Token");
    this.token = token;
    this.tokenFetchedAt = Date.now();
    return token;
  }

  /** GET + JSON. `auth` adds the Bearer token (required for /v1/data/*). */
  private async getJson(path: string, auth = true): Promise<ApiResponse> {
    const headers: Record<string, string> = { Accept: "application/json" };
    if (auth) headers.Authorization = `Bearer ${await this.licenseToken()}`;
    const res = await fetch(`${this.base}${path}`, { headers });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`CMS GET ${path} -> ${res.status} ${body.slice(0, 200)}`);
    }
    return (await res.json()) as ApiResponse;
  }

  /** GET a data endpoint, following next_token pagination, returning all rows. */
  private async getAllRows(path: string): Promise<any[]> {
    const rows: any[] = [];
    let token: string | null | undefined;
    let guard = 0;
    do {
      const sep = path.includes("?") ? "&" : "?";
      const url = token ? `${path}${sep}next_token=${encodeURIComponent(token)}` : path;
      const j = await this.getJson(url);
      if (Array.isArray(j.data)) rows.push(...j.data);
      token = j.meta?.next_token ?? null;
    } while (token && ++guard < 100);
    return rows;
  }

  // ---------------------------------------------------------------- catalog

  /** Full final-LCDs catalog (used by sync to detect new/changed policies). */
  async listFinalLcds(): Promise<LcdCatalogEntry[]> {
    const rows = await this.getAllRows(`/v1/reports/local-coverage-final-lcds`);
    return rows.map((r) => ({
      document_id: r.document_id,
      document_version: r.document_version,
      document_display_id: r.document_display_id,
      document_type: r.document_type,
      title: r.title,
      updated_on: r.updated_on,
      effective_date: r.effective_date,
      retirement_date: r.retirement_date,
      url: r.url,
    }));
  }

  async getLcdCatalogEntry(lcd: string | number): Promise<LcdCatalogEntry | undefined> {
    const id = numericId(lcd);
    const all = await this.listFinalLcds();
    return all.find((e) => e.document_id === id);
  }

  // -------------------------------------------------------------- code tables

  /** Covered HCPCS codes attached to an LCD. */
  async getLcdHcpcCodes(lcd: string | number): Promise<HcpcRow[]> {
    const rows = await this.getAllRows(`/v1/data/lcd/hcpc-code?lcdid=${numericId(lcd)}`);
    return rows.map(toHcpc);
  }

  /** Related article ids for an LCD (the Billing & Coding article holds the ICD-10 tables). */
  async getRelatedArticleIds(lcd: string | number): Promise<number[]> {
    const rows = await this.getAllRows(`/v1/data/lcd/related-documents?lcdid=${numericId(lcd)}`);
    return [...new Set(rows.map((r) => r.r_article_id).filter((x): x is number => typeof x === "number"))];
  }

  async getArticleHcpcCodes(article: string | number): Promise<HcpcRow[]> {
    const rows = await this.getAllRows(`/v1/data/article/hcpc-code?articleid=${numericId(article)}`);
    return rows.map(toHcpc);
  }

  async getArticleIcd10Covered(article: string | number): Promise<Icd10Row[]> {
    const rows = await this.getAllRows(`/v1/data/article/icd10-covered?articleid=${numericId(article)}`);
    return rows.map((r) => ({ icd10_code_id: r.icd10_code_id, description: r.description, group: r.icd10_covered_group }));
  }

  async getArticleIcd10NonCovered(article: string | number): Promise<Icd10Row[]> {
    const rows = await this.getAllRows(`/v1/data/article/icd10-noncovered?articleid=${numericId(article)}`);
    return rows.map((r) => ({ icd10_code_id: r.icd10_code_id, description: r.description, group: r.icd10_noncovered_group }));
  }

  async getArticleModifiers(article: string | number): Promise<ModifierRow[]> {
    const rows = await this.getAllRows(`/v1/data/article/hcpc-modifier?articleid=${numericId(article)}`);
    return rows.map((r) => ({ hcpc_modifier_code_id: r.hcpc_modifier_code_id, description: r.description, group: r.hcpc_modifier_group }));
  }

  // ----------------------------------------------------------------- narrative

  /** Raw LCD detail row (all narrative fields). */
  async getLcdDetailRaw(lcd: string | number): Promise<any> {
    const rows = await this.getAllRows(`/v1/data/lcd?lcdid=${numericId(lcd)}`);
    if (!rows.length) throw new Error(`no LCD detail for ${lcd}`);
    return rows[0];
  }

  /**
   * LCD detail with narrative sections decoded to plain text. The
   * "Coverage Indications, Limitations, and/or Medical Necessity" text — where the
   * numeric/boolean clinical thresholds live — is `sections.indication`.
   */
  async getLcdDetail(lcd: string | number): Promise<LcdDetail> {
    const r = await this.getLcdDetailRaw(lcd);
    const sections: Record<string, string> = {};
    const add = (label: string, raw: any) => {
      const t = htmlToText(raw);
      if (t) sections[label] = t;
    };
    add("Coverage Indications, Limitations, and/or Medical Necessity", r.indication);
    add("Summary of Evidence", r.summary_of_evidence);
    add("Analysis of Evidence", r.analysis_of_evidence);
    add("Documentation Requirements", r.doc_reqs);
    add("Coding Guidelines", r.coding_guidelines);
    add("Utilization Guidelines", r.util_guide);
    add("Diagnoses That Support Medical Necessity", r.diagnoses_support);
    add("ICD-10 Additional Information", r.icd10_doc ?? r.add_icd10_info);
    add("Associated Information", r.associated_info);
    return {
      lcd_id: r.lcd_id,
      lcd_version: r.lcd_version,
      title: r.title,
      effective_date: toISODate(r.rev_eff_date) ?? toISODate(r.orig_det_eff_date),
      url: lcdUrl(r.lcd_id),
      sections,
    };
  }

  /** Concatenated narrative text for an LCD (what fetch-lcd prints for pack authoring). */
  async getLcdText(lcd: string | number): Promise<string> {
    const d = await this.getLcdDetail(lcd);
    const head = `# ${d.title}\nLCD ${d.lcd_id} (version ${d.lcd_version})\n${d.url}\n`;
    const body = Object.entries(d.sections)
      .map(([k, v]) => `\n\n## ${k}\n\n${v}`)
      .join("");
    return head + body;
  }
}

function toHcpc(r: any): HcpcRow {
  return { hcpc_code_id: r.hcpc_code_id, short_description: r.short_description, long_description: r.long_description, hcpc_code_group: r.hcpc_code_group };
}

/** Canonical MCD viewer URL for an LCD numeric id. */
export function lcdUrl(lcdNumericId: number | string): string {
  return `https://www.cms.gov/medicare-coverage-database/view/lcd.aspx?lcdid=${numericId(lcdNumericId)}`;
}

/** Canonical MCD viewer URL for an Article numeric id. */
export function articleUrl(articleNumericId: number | string): string {
  return `https://www.cms.gov/medicare-coverage-database/view/article.aspx?articleid=${numericId(articleNumericId)}`;
}
