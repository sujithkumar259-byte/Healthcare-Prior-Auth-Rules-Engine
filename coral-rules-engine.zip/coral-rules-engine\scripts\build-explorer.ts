// build-explorer — generate a self-contained explorer.html for browsing every pack.
//   npm run explorer   (then open explorer.html in a browser)
import { writeFileSync } from "node:fs";
import { allPacks } from "../src/packs/registry.js";

const checkSummary = (c: any): string => {
  // compact human-ish rendering of a Check
  const r = (x: any): string => {
    switch (x?.op) {
      case "present": return `present(${x.path})`;
      case "absent": return `absent(${x.path})`;
      case "nonEmpty": return `nonEmpty(${x.path})`;
      case "cmp": return `${x.path} ${x.cmp} ${JSON.stringify(x.value)}`;
      case "in": return `${x.path} in [${x.values.slice(0, 6).join(", ")}${x.values.length > 6 ? ", …" : ""}]`;
      case "ratio": return `${x.num}/${x.den} ${x.cmp} ${x.value}${x.minDen ? ` (minDen ${x.minDen})` : ""}`;
      case "all": return `ALL(${x.of.map(r).join(" AND ")})`;
      case "any": return `ANY(${x.of.map(r).join(" OR ")})`;
      case "not": return `NOT(${r(x.of)})`;
      default: return JSON.stringify(x);
    }
  };
  return r(c);
};

const packs = allPacks().map((v) => ({
  payer: v.key.payer,
  category: v.key.category,
  status: v.status,
  effective: v.effective_date,
  issuer: v.source.issuer,
  doc_id: v.source.doc_id,
  url: v.source.url,
  notes: v.notes ?? "",
  items: v.key.items,
  criteria: v.criteria.map((c) => ({
    id: c.id,
    hard: c.hard,
    phase: c.phase ?? "",
    description: c.description,
    check: checkSummary(c.check),
    section: c.source.section ?? "",
    url: c.source.url,
    gap: c.gap,
  })),
}));

const totals = {
  packs: packs.length,
  criteria: packs.reduce((n, p) => n + p.criteria.length, 0),
  active: packs.filter((p) => p.status === "active").length,
  pending: packs.filter((p) => p.status === "pending_review").length,
  byPayer: [...new Set(packs.map((p) => p.payer))].map((pay) => ({ payer: pay, packs: packs.filter((p) => p.payer === pay).length })),
};

const DATA = JSON.stringify({ totals, packs });

const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Prior-Auth Rules Engine — Explorer</title>
<style>
:root{--bg:#0b1020;--card:#141b2e;--ink:#e7ecf5;--mut:#93a0bd;--line:#26304a;--accent:#5b8cff;--ok:#37d39b;--warn:#f5b94a;--hard:#ff7a7a}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 ui-sans-serif,system-ui,Segoe UI,Roboto,Arial}
header{padding:18px 22px;border-bottom:1px solid var(--line);position:sticky;top:0;background:linear-gradient(180deg,#0b1020,#0b1020f0);backdrop-filter:blur(6px);z-index:5}
h1{font-size:18px;margin:0 0 6px}.sub{color:var(--mut);font-size:13px}
.stats{display:flex;gap:18px;flex-wrap:wrap;margin-top:10px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:8px 12px}
.stat b{font-size:18px}.stat span{color:var(--mut);font-size:12px;display:block}
.controls{display:flex;gap:10px;flex-wrap:wrap;padding:14px 22px;position:sticky;top:118px;background:var(--bg);border-bottom:1px solid var(--line);z-index:4}
input,select{background:var(--card);border:1px solid var(--line);color:var(--ink);border-radius:8px;padding:8px 10px;font-size:13px}
input[type=search]{flex:1;min-width:220px}
main{padding:14px 22px;max-width:1100px;margin:0 auto}
.pack{background:var(--card);border:1px solid var(--line);border-radius:12px;margin:10px 0;overflow:hidden}
.phead{display:flex;align-items:center;gap:10px;padding:12px 14px;cursor:pointer}
.phead:hover{background:#18203a}
.pill{font-size:11px;padding:2px 8px;border-radius:999px;border:1px solid var(--line);color:var(--mut)}
.pill.payer{color:var(--accent);border-color:#2b3c66}
.pill.active{color:var(--ok);border-color:#1f5f47}.pill.pending{color:var(--warn);border-color:#5e4a1c}
.cat{font-weight:600;flex:1}.count{color:var(--mut);font-size:12px}
.body{display:none;padding:0 14px 12px;border-top:1px solid var(--line)}
.body.open{display:block}
.src{color:var(--mut);font-size:12px;margin:8px 0}
.crit{border-top:1px dashed var(--line);padding:9px 0}
.crit .d{font-weight:500}
.crit .meta{color:var(--mut);font-size:12px;margin-top:2px}
.tag{font-size:10px;padding:1px 6px;border-radius:6px;border:1px solid var(--line);margin-right:6px}
.tag.hard{color:var(--hard);border-color:#5e2626}.tag.soft{color:var(--mut)}
.check{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;color:#bcd0ff;background:#0e1426;border:1px solid var(--line);border-radius:6px;padding:6px 8px;margin-top:5px;white-space:pre-wrap;word-break:break-word}
a{color:var(--accent)}.muted{color:var(--mut)}
.note{color:var(--warn);font-size:12px;margin:6px 0}
</style></head><body>
<header>
<h1>Prior-Authorization Rules Engine — coverage explorer</h1>
<div class="sub">Every policy pack the engine has loaded. All packs are <b>pending_review</b> — none is live until a clinician approves it. Each criterion links to its source document.</div>
<div class="stats" id="stats"></div>
</header>
<div class="controls">
<input type="search" id="q" placeholder="Search category, criterion text, code, doc id…">
<select id="payer"><option value="">All payers</option></select>
<select id="status"><option value="">All statuses</option><option value="active">active</option><option value="pending_review">pending_review</option></select>
<select id="sort"><option value="cat">Sort: A–Z</option><option value="crit">Sort: most criteria</option></select>
</div>
<main id="list"></main>
<script>
const D = ${DATA};
const el=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e};
const stats=document.getElementById('stats');
stats.append(
 mk('Packs',D.totals.packs), mk('Criteria',D.totals.criteria),
 mk('Active',D.totals.active), mk('Pending review',D.totals.pending),
 ...D.totals.byPayer.map(p=>mk(p.payer,p.packs)));
function mk(label,val){const d=el('div','stat');d.innerHTML='<b>'+val+'</b><span>'+label+'</span>';return d}
const psel=document.getElementById('payer');
[...new Set(D.packs.map(p=>p.payer))].forEach(p=>{const o=el('option');o.value=p;o.textContent=p;psel.append(o)});
const esc=s=>(s||'').replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));
function render(){
 const q=document.getElementById('q').value.toLowerCase();
 const pf=psel.value, sf=document.getElementById('status').value, sort=document.getElementById('sort').value;
 let rows=D.packs.filter(p=>(!pf||p.payer===pf)&&(!sf||p.status===sf));
 if(q)rows=rows.filter(p=>p.category.toLowerCase().includes(q)||p.doc_id.toLowerCase().includes(q)||p.criteria.some(c=>(c.description+' '+c.check+' '+c.id).toLowerCase().includes(q)));
 rows.sort((a,b)=>sort==='crit'?b.criteria.length-a.criteria.length:a.category.localeCompare(b.category));
 const list=document.getElementById('list');list.innerHTML='';
 list.append(el('div','muted','Showing '+rows.length+' packs'));
 for(const p of rows){
  const pack=el('div','pack');
  const head=el('div','phead');
  head.innerHTML='<span class="pill payer">'+esc(p.payer)+'</span>'+
   '<span class="pill '+(p.status==='active'?'active':'pending')+'">'+p.status.replace('_',' ')+'</span>'+
   '<span class="cat">'+esc(p.category)+'</span>'+
   '<span class="count">'+p.criteria.length+' criteria · '+esc(p.doc_id)+'</span>';
  const body=el('div','body');
  let h='<div class="src">Source: '+esc(p.issuer)+' '+esc(p.doc_id)+' · effective '+esc(p.effective)+' · <a href="'+p.url+'" target="_blank" rel="noreferrer">document</a></div>';
  if(p.notes)h+='<div class="note">'+esc(p.notes)+'</div>';
  for(const c of p.criteria){
   h+='<div class="crit"><div class="d"><span class="tag '+(c.hard?'hard':'soft')+'">'+(c.hard?'HARD':'soft')+'</span>'+
      (c.phase?'<span class="tag soft">'+esc(c.phase)+'</span>':'')+esc(c.description)+'</div>'+
      '<div class="check">'+esc(c.check)+'</div>'+
      '<div class="meta">'+esc(c.id)+(c.section?' · §'+esc(c.section):'')+'</div></div>';
  }
  body.innerHTML=h;
  head.onclick=()=>body.classList.toggle('open');
  pack.append(head,body);list.append(pack);
 }
}
['q','payer','status','sort'].forEach(id=>document.getElementById(id).addEventListener('input',render));
render();
</script></body></html>`;

writeFileSync("explorer.html", html);
console.log(`built explorer.html  (${totals.packs} packs, ${totals.criteria} criteria, ${(html.length / 1024).toFixed(0)} KB)`);
