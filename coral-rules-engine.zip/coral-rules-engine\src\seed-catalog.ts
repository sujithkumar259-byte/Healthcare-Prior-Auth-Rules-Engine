// Loader for seed-catalog.json — the one human-curated lookup that maps a CMS document
// to the category (and key) it governs. Categories are not derivable from the API alone.
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

export interface SeedPolicy {
  category: string;
  lcd: string;
  ncd?: string;
  effective: string;
  status: string;
  title?: string;
  url?: string;
}

export interface SeedCatalog {
  payer: string;
  jurisdiction: string;
  notes?: string;
  policies: SeedPolicy[];
}

export function loadSeedCatalog(): SeedCatalog {
  const here = dirname(fileURLToPath(import.meta.url));
  const path = join(here, "..", "seed-catalog.json");
  return JSON.parse(readFileSync(path, "utf8")) as SeedCatalog;
}

/** Find the seed entry for an LCD display id (e.g. "L33797") or a category name. */
export function findSeed(catalog: SeedCatalog, lcdOrCategory: string): SeedPolicy | undefined {
  const needle = lcdOrCategory.toLowerCase();
  return catalog.policies.find(
    (p) => p.lcd.toLowerCase() === needle || p.category.toLowerCase() === needle,
  );
}
