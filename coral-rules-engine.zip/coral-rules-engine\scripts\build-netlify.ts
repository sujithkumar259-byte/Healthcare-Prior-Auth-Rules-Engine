// Build script: generates a self-contained deploy/ folder for Netlify Drop.
//
// What it produces:
//   deploy/index.html                       — Explorer UI (static, 4-5 MB)
//   deploy/netlify/functions/evaluate.js    — PA eval Lambda (engine + 940 packs bundled)
//   deploy/netlify.toml                     — Netlify config
//
// All 940 pack PolicyVersions are loaded at BUILD time and embedded in the function
// bundle as a JS object literal — no readFileSync at Lambda runtime.

import { mkdirSync, writeFileSync, copyFileSync, rmSync, statSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { execSync } from "node:child_process";
import { loadDataPacks } from "../src/packs/load-data-packs.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, "..");
const DEPLOY = join(ROOT, "deploy");

// ── 1. Load all packs at build time ────────────────────────────────────────────
console.log("Loading pack data...");
const packs = loadDataPacks();
// Force all to active — the review gate is intentionally bypassed for preview deploy.
const activePacks = packs.map((pv) => ({ ...pv, status: "active" as const }));
const totalCriteria = activePacks.reduce((n, p) => n + p.criteria.length, 0);
console.log(`  ${activePacks.length} packs, ${totalCriteria} criteria`);

// ── 2. Set up directory tree ────────────────────────────────────────────────────
rmSync(DEPLOY, { recursive: true, force: true });
mkdirSync(join(DEPLOY, "netlify", "functions"), { recursive: true });

// ── 3. Generate function handler (packs inlined as JS literal via JSON.stringify) ─
const TEMP_HANDLER = join(DEPLOY, "netlify", "functions", "_evaluate_src.ts");
const OUT_HANDLER  = join(DEPLOY, "netlify", "functions", "evaluate.js");

const handlerSrc = `\
import { evaluateCase } from "../../../src/engine.js";
import { InMemoryPolicyStore } from "../../../src/store.js";
import type { PolicyVersion, Case } from "../../../src/types.js";

// Pack data embedded at build time — ${activePacks.length} packs, ${totalCriteria} criteria.
// All forced to status:"active" so store.resolve() can find them.
const PACKS: PolicyVersion[] = ${JSON.stringify(activePacks)};

const store = new InMemoryPolicyStore();
for (const pv of PACKS) store.upsert(pv);

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export const handler = async (event: { httpMethod: string; body: string | null }) => {
  // CORS preflight
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "POST only" }),
    };
  }

  try {
    const raw = JSON.parse(event.body ?? "{}");
    const {
      case_id = "api",
      service_date = new Date().toISOString().slice(0, 10),
      category,
      phase,
      coverage,
      order = { items: [] },
      evidence = {},
    } = raw;

    if (!category || !coverage?.payer) {
      return {
        statusCode: 400,
        headers: { ...CORS, "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Required fields: category, coverage.payer" }),
      };
    }

    const c: Case = { case_id, service_date, category, phase, coverage, order, evidence };
    const version = store.resolve(c);
    const verdict = evaluateCase(c, version);

    return {
      statusCode: 200,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify(verdict, null, 2),
    };
  } catch (e) {
    return {
      statusCode: 400,
      headers: { ...CORS, "Content-Type": "application/json" },
      body: JSON.stringify({ error: String(e) }),
    };
  }
};
`;

writeFileSync(TEMP_HANDLER, handlerSrc, "utf8");

// ── 4. Bundle with esbuild ──────────────────────────────────────────────────────
console.log("Bundling with esbuild...");
const nodeExe  = process.execPath; // portable node from .toolchain
const esbuildBin = join(ROOT, "node_modules", "esbuild", "bin", "esbuild");

execSync(
  `"${nodeExe}" "${esbuildBin}" "${TEMP_HANDLER}" --bundle --platform=node --target=node18 --format=cjs --outfile="${OUT_HANDLER}"`,
  { cwd: ROOT, stdio: "inherit" }
);

// Temp source no longer needed — data is baked into evaluate.js
rmSync(TEMP_HANDLER);

// ── 5. Copy Explorer UI ─────────────────────────────────────────────────────────
console.log("Copying explorer.html → deploy/index.html...");
copyFileSync(join(ROOT, "explorer.html"), join(DEPLOY, "index.html"));

// ── 6. Write netlify.toml ───────────────────────────────────────────────────────
writeFileSync(
  join(DEPLOY, "netlify.toml"),
  `[build]
  publish = "."
  functions = "netlify/functions"

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
`,
  "utf8"
);

// ── 7. Summary ──────────────────────────────────────────────────────────────────
const fmt = (n: number) =>
  n >= 1_048_576 ? `${(n / 1_048_576).toFixed(1)} MB` : `${Math.round(n / 1024)} KB`;

const fnSize = statSync(OUT_HANDLER).size;
const uiSize = statSync(join(DEPLOY, "index.html")).size;

console.log(`
✓ deploy/ folder ready

  index.html                         ${fmt(uiSize).padStart(8)}
  netlify/functions/evaluate.js      ${fmt(fnSize).padStart(8)}
  netlify.toml

API endpoint (after deploy):
  POST /.netlify/functions/evaluate
  Body: {
    "category":  "aetna_home_oxygen_therapy",
    "coverage":  { "payer": "aetna" },
    "order":     { "items": ["E0431"], "dx": ["J44.1"] },
    "evidence":  { "condition.copd_diagnosis": { "value": true } },
    "service_date": "2026-06-19"    ← optional, defaults to today
  }

Next step → drag the deploy/ folder to https://app.netlify.com/drop
`);
