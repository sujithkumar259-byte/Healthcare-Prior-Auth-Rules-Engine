// Structural validator for Check objects.
//
// The interpreter (dsl.ts) is intentionally forgiving (an unknown shape just yields false).
// But authored/generated criteria are DATA, and bad data must fail LOUDLY at load time rather
// than silently mis-evaluating a coverage decision. validateCheck returns a list of problems;
// an empty list means the check is well-formed.

import { Check } from "./types.js";

const CMP_OPS = new Set([">=", "<=", ">", "<", "==", "!="]);
const RATIO_OPS = new Set([">=", "<=", ">", "<"]);

export function validateCheck(check: unknown, path = "check"): string[] {
  const errs: string[] = [];
  if (check === null || typeof check !== "object") {
    return [`${path}: expected an object, got ${typeof check}`];
  }
  const c = check as Record<string, unknown>;
  const op = c.op;
  const needsString = (k: string) => {
    if (typeof c[k] !== "string" || (c[k] as string).length === 0) errs.push(`${path}.${k}: expected non-empty string`);
  };
  switch (op) {
    case "present":
    case "absent":
    case "nonEmpty":
      needsString("path");
      break;
    case "cmp":
      needsString("path");
      if (!CMP_OPS.has(c.cmp as string)) errs.push(`${path}.cmp: invalid comparator ${JSON.stringify(c.cmp)}`);
      if (!["number", "string", "boolean"].includes(typeof c.value)) errs.push(`${path}.value: expected number|string|boolean`);
      break;
    case "in":
      needsString("path");
      if (!Array.isArray(c.values) || c.values.length === 0) errs.push(`${path}.values: expected a non-empty array`);
      else if (!c.values.every((v) => typeof v === "string" || typeof v === "number")) errs.push(`${path}.values: only string|number members`);
      break;
    case "ratio":
      needsString("num");
      needsString("den");
      if (!RATIO_OPS.has(c.cmp as string)) errs.push(`${path}.cmp: invalid ratio comparator ${JSON.stringify(c.cmp)}`);
      if (typeof c.value !== "number") errs.push(`${path}.value: expected number`);
      if (c.minDen !== undefined && typeof c.minDen !== "number") errs.push(`${path}.minDen: expected number`);
      break;
    case "all":
    case "any":
      if (!Array.isArray(c.of) || c.of.length === 0) errs.push(`${path}.of: expected a non-empty array`);
      else c.of.forEach((sub, i) => errs.push(...validateCheck(sub, `${path}.of[${i}]`)));
      break;
    case "not":
      if (c.of === undefined) errs.push(`${path}.of: required`);
      else errs.push(...validateCheck(c.of, `${path}.of`));
      break;
    default:
      errs.push(`${path}.op: unknown operator ${JSON.stringify(op)}`);
  }
  return errs;
}

/** Throw if the check is malformed. Returns the check typed, for fluent use. */
export function assertValidCheck(check: unknown, ctx: string): Check {
  const errs = validateCheck(check);
  if (errs.length) throw new Error(`invalid check in ${ctx}:\n  - ${errs.join("\n  - ")}`);
  return check as Check;
}
