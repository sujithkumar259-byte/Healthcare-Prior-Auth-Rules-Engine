// demo-update — proves a policy update is a DATA swap, governed by review + effective date,
// with ZERO engine code change. Simulates Cigna tightening bariatric BMI from >=35 to >=40.
import { InMemoryPolicyStore, ReviewQueue } from "../src/store.js";
import { evaluateCase } from "../src/engine.js";
import { allPacks } from "../src/packs/registry.js";
import { Case, PolicyVersion } from "../src/types.js";

const store = new InMemoryPolicyStore();
const review = new ReviewQueue(store);

// Take the real authored bariatric pack and keep only its BMI criterion for a clean demo.
const base = allPacks().find((p) => p.key.category === "cigna_bariatric_surgery")!;
const bmiCrit = base.criteria.find((c) => c.id.includes("bmi"))!;

const v1: PolicyVersion = {
  ...structuredClone(base),
  version_id: "cigna-bariatric-2024",
  status: "active",
  effective_date: "2024-01-01",
  criteria: [structuredClone(bmiCrit)],
};

// === THE UPDATE: edit DATA only. New version, BMI threshold 35 -> 40, later effective date. ===
const v2: PolicyVersion = {
  ...structuredClone(base),
  version_id: "cigna-bariatric-2026",
  status: "pending_review",
  effective_date: "2026-06-01",
  criteria: [structuredClone(bmiCrit)],
};
(v2.criteria[0]!.check as any).of[0].value = 40; // the only change — a number in a JSON-shaped object

store.upsert(v1);
store.upsert(v2);

const patient = (service_date: string): Case => ({
  case_id: "demo", service_date, category: "cigna_bariatric_surgery", phase: "initial",
  coverage: { payer: "cigna", jurisdiction: "national" },
  order: { items: ["43775"] },
  evidence: { "patient.bmi_kg_m2": { value: 37, confidence: 0.99 }, "patient.obesity_comorbidity_count": { value: 0, confidence: 0.99 } },
});

const show = (label: string, c: Case) => {
  const v = store.resolve(c);
  const verdict = evaluateCase(c, v);
  console.log(`  ${label}: resolved ${v?.version_id ?? "(none)"} -> ${verdict.verdict.toUpperCase()}`);
};

console.log("Patient BMI 37, no comorbidities. Watch the verdict swap by date + review state.\n");
console.log("1) v2 staged as pending_review (not yet approved):");
show("service 2026-12-01", patient("2026-12-01"));
console.log("   -> still uses v1 (BMI>=35): BMI 37 qualifies. Pending versions never resolve.\n");

console.log("2) A human approves the update:");
review.approve("cigna-bariatric-2026", "sujith");
show("service 2026-12-01", patient("2026-12-01"));
show("service 2025-06-01", patient("2025-06-01"));
console.log("   -> 2026 case now uses v2 (BMI>=40): BMI 37 no longer qualifies -> needs_info.");
console.log("   -> 2025 case still uses v1: history preserved (old claims judged by old rules).");
console.log("\nNo engine code was touched. The update was: new JSON version + a changed number + approve.");
