// Acceptance 3: the DSL interpreter handles every operator and never executes data as code.
import { test, eq, ok, section } from "./harness.js";
import { evalCheck } from "../src/dsl.js";
import { Case } from "../src/types.js";

const mk = (evidence: Case["evidence"], order: Partial<Case["order"]> = {}): Case => ({
  case_id: "T",
  service_date: "2026-01-01",
  category: "dme_pap",
  coverage: { payer: "medicare" },
  order: { items: [], ...order },
  evidence,
});

export function dslTests(): void {
  section("DSL interpreter (Acceptance 3)");

  test("present / absent", () => {
    const c = mk({ a: { value: 1 }, b: { value: null } });
    ok(evalCheck(c, { op: "present", path: "a" }));
    ok(!evalCheck(c, { op: "present", path: "b" }));
    ok(!evalCheck(c, { op: "present", path: "missing" }));
    ok(evalCheck(c, { op: "absent", path: "missing" }));
    ok(evalCheck(c, { op: "absent", path: "b" }));
  });

  test("nonEmpty (array and truthy)", () => {
    const c = mk({ arr: { value: [1] }, empty: { value: [] }, str: { value: "x" }, zero: { value: 0 } });
    ok(evalCheck(c, { op: "nonEmpty", path: "arr" }));
    ok(!evalCheck(c, { op: "nonEmpty", path: "empty" }));
    ok(evalCheck(c, { op: "nonEmpty", path: "str" }));
    ok(!evalCheck(c, { op: "nonEmpty", path: "zero" }));
  });

  test("cmp numeric + bool + string", () => {
    const c = mk({ n: { value: 15 }, flag: { value: true }, s: { value: "G47.33" } });
    ok(evalCheck(c, { op: "cmp", path: "n", cmp: ">=", value: 15 }));
    ok(!evalCheck(c, { op: "cmp", path: "n", cmp: ">", value: 15 }));
    ok(evalCheck(c, { op: "cmp", path: "flag", cmp: "==", value: true }));
    ok(evalCheck(c, { op: "cmp", path: "s", cmp: "==", value: "G47.33" }));
    ok(evalCheck(c, { op: "cmp", path: "s", cmp: "!=", value: "G47.30" }));
  });

  test("cmp does not coerce types (string '15' != number 15)", () => {
    const c = mk({ n: { value: "15" } });
    ok(!evalCheck(c, { op: "cmp", path: "n", cmp: ">=", value: 15 }), "string should not satisfy numeric >=");
    ok(!evalCheck(c, { op: "cmp", path: "n", cmp: "==", value: 15 }), "strict equality, no coercion");
  });

  test("in (scalar membership)", () => {
    const c = mk({ x: { value: "E0601" } });
    ok(evalCheck(c, { op: "in", path: "x", values: ["E0601", "E0470"] }));
    ok(!evalCheck(c, { op: "in", path: "x", values: ["E0470"] }));
  });

  test("in with [*] (any dx in covered set) reads order.dx", () => {
    const c = mk({}, { dx: ["G47.33", "I10"] });
    ok(evalCheck(c, { op: "in", path: "order.dx[*]", values: ["G47.33"] }), "one dx in set");
    ok(!evalCheck(c, { op: "in", path: "order.dx[*]", values: ["E66.9"] }), "no dx in set");
  });

  test("not(in [*]) implements non-covered exclusion", () => {
    const covered = mk({}, { dx: ["G47.33"] });
    const excluded = mk({}, { dx: ["R06.3"] });
    const noncovered = ["R06.3"];
    ok(evalCheck(covered, { op: "not", of: { op: "in", path: "order.dx[*]", values: noncovered } }), "clean dx passes");
    ok(!evalCheck(excluded, { op: "not", of: { op: "in", path: "order.dx[*]", values: noncovered } }), "excluded dx fails");
  });

  test("ratio with minDen floor and div-by-zero", () => {
    const ok30 = mk({ n: { value: 26 }, d: { value: 30 } });
    const tooFew = mk({ n: { value: 10 }, d: { value: 10 } });
    const zero = mk({ n: { value: 0 }, d: { value: 0 } });
    ok(evalCheck(ok30, { op: "ratio", num: "n", den: "d", cmp: ">=", value: 0.7, minDen: 30 }));
    ok(!evalCheck(tooFew, { op: "ratio", num: "n", den: "d", cmp: ">=", value: 0.7, minDen: 30 }), "minDen not met");
    ok(!evalCheck(zero, { op: "ratio", num: "n", den: "d", cmp: ">=", value: 0.7 }), "den 0 -> false");
  });

  test("ratio returns false on non-numeric operands", () => {
    const c = mk({ n: { value: "lots" }, d: { value: 30 } });
    ok(!evalCheck(c, { op: "ratio", num: "n", den: "d", cmp: ">=", value: 0.7 }));
  });

  test("all / any / not composition", () => {
    const c = mk({ a: { value: 5 }, b: { value: 10 } });
    ok(evalCheck(c, { op: "all", of: [{ op: "cmp", path: "a", cmp: "==", value: 5 }, { op: "cmp", path: "b", cmp: "==", value: 10 }] }));
    ok(evalCheck(c, { op: "any", of: [{ op: "cmp", path: "a", cmp: "==", value: 999 }, { op: "cmp", path: "b", cmp: "==", value: 10 }] }));
    ok(evalCheck(c, { op: "not", of: { op: "cmp", path: "a", cmp: "==", value: 999 } }));
  });

  test("resolves structural case fields (order.prescriber_npi)", () => {
    const c = mk({}, { prescriber_npi: "1992001122" });
    ok(evalCheck(c, { op: "present", path: "order.prescriber_npi" }));
    const none = mk({});
    ok(!evalCheck(none, { op: "present", path: "order.prescriber_npi" }));
  });

  test("HOSTILE INPUT is treated as data, never executed", () => {
    // Classic injection strings as evidence values. The interpreter must compare them
    // as opaque data and never evaluate them.
    const payloads = [
      "process.exit(1)",
      "require('child_process').execSync('calc')",
      "__proto__",
      "constructor.constructor('return process')()",
      "'; DROP TABLE policies;--",
      "${global.process.mainModule}",
    ];
    for (const p of payloads) {
      const c = mk({ evil: { value: p } });
      // Equality against a different literal must simply be false — and nothing runs.
      ok(!evalCheck(c, { op: "cmp", path: "evil", cmp: "==", value: "expected" }), `payload not matched: ${p}`);
      // Matching the exact same string is plain data equality, still no execution.
      ok(evalCheck(c, { op: "cmp", path: "evil", cmp: "==", value: p }), `payload compared as data: ${p}`);
      // It must never be usable as a numeric threshold.
      ok(!evalCheck(c, { op: "cmp", path: "evil", cmp: ">=", value: 1 }), `payload not numeric: ${p}`);
    }
    // Prototype-pollution-style key must not resolve to Object.prototype machinery.
    const proto = mk({});
    eq(evalCheck(proto, { op: "present", path: "__proto__.constructor" }), false, "no prototype walk");
  });
}
