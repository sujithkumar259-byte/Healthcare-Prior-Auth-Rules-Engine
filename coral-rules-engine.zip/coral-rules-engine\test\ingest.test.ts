// Acceptance 4: structured ingest produces ICD-10 `in` criteria and HCPCS present/in
// criteria from the code tables, each with a source, with NO LLM call.
// Acceptance 6: every generated criterion has a non-empty source.doc_id and source.url.
//
// These run against FIXTURE rows (no network) so the suite is deterministic; the live
// end-to-end path is exercised by `npm run ingest -- L33718`.
import { test, eq, ok, section } from "./harness.js";
import { hcpcsCoverageCriterion, icd10CoveredCriterion, icd10NonCoveredCriterion } from "../src/ingest-structured.js";
import { evalCheck } from "../src/dsl.js";
import { Case, SourceRef } from "../src/types.js";

const LCD_SRC: SourceRef = { issuer: "CMS", doc_type: "LCD", doc_id: "L33718", section: "HCPCS Codes", url: "https://www.cms.gov/medicare-coverage-database/view/lcd.aspx?lcdid=33718" };
const ART_SRC: SourceRef = { issuer: "CMS", doc_type: "ARTICLE", doc_id: "A52467", section: "ICD-10 Covered", url: "https://www.cms.gov/medicare-coverage-database/view/article.aspx?articleid=52467" };

const mkCase = (items: string[], dx: string[]): Case => ({
  case_id: "I", service_date: "2026-01-01", category: "dme_pap",
  coverage: { payer: "medicare" }, order: { items, dx }, evidence: {},
});

export function ingestTests(): void {
  section("Structured ingest -> criteria (Acceptance 4, 6)");

  test("HCPCS coverage -> present/in check on order.items", () => {
    const c = hcpcsCoverageCriterion([{ hcpc_code_id: "E0601" }, { hcpc_code_id: "E0470" }], LCD_SRC, "dme_pap_L33718")!;
    ok(c, "criterion produced");
    eq(c.check.op, "all");
    const ops = c.check.op === "all" ? c.check.of.map((x) => x.op) : [];
    ok(ops.includes("present"), "has present sub-check");
    ok(ops.includes("in"), "has in sub-check on order.items");
    // satisfied when an ordered item is covered; unmet when not
    ok(evalCheck(mkCase(["E0601"], []), c.check), "covered item satisfies");
    ok(!evalCheck(mkCase(["E9999"], []), c.check), "uncovered item fails");
  });

  test("ICD-10 covered -> { in, order.dx[*] } (any dx in covered set)", () => {
    const c = icd10CoveredCriterion([{ icd10_code_id: "G47.33" }], ART_SRC, "dme_pap_L33718")!;
    eq(c.check.op, "in");
    if (c.check.op === "in") eq(c.check.path, "order.dx[*]");
    ok(evalCheck(mkCase(["E0601"], ["G47.33"]), c.check), "covered dx satisfies");
    ok(!evalCheck(mkCase(["E0601"], ["E66.9"]), c.check), "non-listed dx fails");
  });

  test("ICD-10 non-covered -> not(in) exclusion", () => {
    const c = icd10NonCoveredCriterion([{ icd10_code_id: "R06.3" }], ART_SRC, "dme_pap_L33718")!;
    eq(c.check.op, "not");
    ok(evalCheck(mkCase(["E0601"], ["G47.33"]), c.check), "clean dx passes exclusion");
    ok(!evalCheck(mkCase(["E0601"], ["R06.3"]), c.check), "excluded dx fails");
  });

  test("empty tables -> null (no empty criteria)", () => {
    eq(hcpcsCoverageCriterion([], LCD_SRC, "x"), null);
    eq(icd10CoveredCriterion([], ART_SRC, "x"), null);
    eq(icd10NonCoveredCriterion([], ART_SRC, "x"), null);
  });

  test("every generated criterion carries source.doc_id + source.url (Acceptance 6)", () => {
    const crits = [
      hcpcsCoverageCriterion([{ hcpc_code_id: "E0601" }], LCD_SRC, "x")!,
      icd10CoveredCriterion([{ icd10_code_id: "G47.33" }], ART_SRC, "x")!,
      icd10NonCoveredCriterion([{ icd10_code_id: "R06.3" }], ART_SRC, "x")!,
    ];
    for (const c of crits) {
      ok(c.source.doc_id.length > 0, `${c.id} doc_id`);
      ok(c.source.url.startsWith("http"), `${c.id} url`);
    }
  });
}
