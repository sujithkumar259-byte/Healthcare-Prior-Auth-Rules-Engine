// Acceptance 1: PAP appendix case -> submit_ready; flip improved -> needs_info;
// drop adherence confidence -> abstain.
import { test, eq, ok, section } from "./harness.js";
import { InMemoryPolicyStore } from "../src/store.js";
import { evaluateCase, evaluateCriterion } from "../src/engine.js";
import { allPacks } from "../src/packs/registry.js";
import { Case } from "../src/types.js";

const baseCase: Case = {
  case_id: "PA-3001",
  service_date: "2026-06-11",
  category: "dme_pap",
  phase: "continued",
  coverage: { payer: "medicare", jurisdiction: "national" },
  order: { items: ["E0601"], dx: ["G47.33"], prescriber_npi: "1992001122" },
  evidence: {
    "adherence.nights_used_ge4h": { value: 26, confidence: 0.97 },
    "adherence.total_nights": { value: 30, confidence: 0.97 },
    "benefit_reeval.improved": { value: true, confidence: 0.95 },
  },
};

export function engineTests(): void {
  section("Engine (Acceptance 1)");
  const store = new InMemoryPolicyStore();
  // All packs now ship pending_review (no pack is active until a clinician approves it).
  // The engine tests exercise evaluation logic against the PAP pack, so we approve it here
  // by upserting it as active into this test's store.
  const papVersion = allPacks().find((v) => v.key.category === "dme_pap")!;
  store.upsert({ ...papVersion, status: "active" });

  test("appendix case -> submit_ready", () => {
    const v = evaluateCase(baseCase, store.resolve(baseCase));
    eq(v.verdict, "submit_ready");
    eq(v.policy_version_id, papVersion.version_id); // resolves the active golden PAP pack
  });

  test("benefit_reeval.improved = false -> needs_info", () => {
    const c: Case = { ...baseCase, evidence: { ...baseCase.evidence, "benefit_reeval.improved": { value: false, confidence: 0.95 } } };
    eq(evaluateCase(c, store.resolve(c)).verdict, "needs_info");
  });

  test("adherence confidence 0.6 -> abstain", () => {
    const c: Case = { ...baseCase, evidence: { ...baseCase.evidence, "adherence.nights_used_ge4h": { value: 26, confidence: 0.6 } } };
    const v = evaluateCase(c, store.resolve(c));
    eq(v.verdict, "abstain");
    ok(v.results.some((r) => r.criterion_id === "med_cont_adherence" && r.status === "uncertain"));
  });

  test("only phase-matching criteria are evaluated", () => {
    const v = evaluateCase(baseCase, store.resolve(baseCase));
    ok(v.results.every((r) => r.criterion_id.startsWith("med_cont_")), "continued phase only");
    eq(v.results.length, 2);
  });

  test("needs_info wins over abstain when both present", () => {
    const c: Case = {
      ...baseCase,
      evidence: {
        "adherence.nights_used_ge4h": { value: 10, confidence: 0.97 }, // unmet ratio
        "adherence.total_nights": { value: 30, confidence: 0.97 },
        "benefit_reeval.improved": { value: true, confidence: 0.5 }, // uncertain
      },
    };
    eq(evaluateCase(c, store.resolve(c)).verdict, "needs_info");
  });

  test("missing required evidence -> needs_info with gap action", () => {
    const c: Case = { ...baseCase, evidence: { "benefit_reeval.improved": { value: true, confidence: 0.95 } } };
    const v = evaluateCase(c, store.resolve(c));
    eq(v.verdict, "needs_info");
    const adh = v.results.find((r) => r.criterion_id === "med_cont_adherence");
    eq(adh?.status, "missing");
    eq(adh?.confidence, null);
    ok(adh?.gap_action?.includes("adherence report"));
  });

  test("no version -> no_policy", () => {
    eq(evaluateCase(baseCase, null).verdict, "no_policy");
  });

  test("evaluateCriterion: present + tau boundary", () => {
    const cr = papVersion.criteria.find((x) => x.id === "med_cont_reeval")!;
    const at = evaluateCriterion({ ...baseCase, evidence: { "benefit_reeval.improved": { value: true, confidence: 0.85 } } }, cr);
    eq(at.status, "satisfied", "conf == tau is satisfied");
    const below = evaluateCriterion({ ...baseCase, evidence: { "benefit_reeval.improved": { value: true, confidence: 0.84 } } }, cr);
    eq(below.status, "uncertain", "conf < tau abstains");
  });

  section("Source traceability (Acceptance 6)");
  test("every PAP criterion has source.doc_id and source.url", () => {
    for (const cr of papVersion.criteria) {
      ok(cr.source.doc_id && cr.source.doc_id.length > 0, `${cr.id} doc_id`);
      ok(cr.source.url && cr.source.url.startsWith("http"), `${cr.id} url`);
    }
  });
}
