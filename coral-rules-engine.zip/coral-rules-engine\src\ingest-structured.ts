// 8a — STRUCTURED INGEST (no LLM, no key beyond the license token).
//
// Turns CMS structured code tables into deterministic Criteria. This is table-to-rule:
// no prose is parsed, no model is called. Every generated criterion carries a SourceRef
// pointing at the originating document. The assembled PolicyVersion is always
// `pending_review` — a human approves it before it can resolve.

import { CmsClient, HcpcRow, Icd10Row, ModifierRow, articleUrl, lcdUrl, numericId, toISODate } from "./cms-client.js";
import { Criterion, PolicyVersion, SourceRef } from "./types.js";

export interface IngestOptions {
  lcd: string | number; // "L33718"
  category: string; // "dme_pap" — the one human-supplied label (from seed-catalog)
  payer?: string; // default "medicare"
  jurisdiction?: string; // default "national"
}

// ------------------------------------------------------------- pure transforms

const uniq = (xs: string[]) => [...new Set(xs)].sort();

/**
 * HCPCS coverage -> present/in checks on order.items.
 * "The order lists an item, and it is one of the codes this policy governs."
 */
export function hcpcsCoverageCriterion(codes: HcpcRow[], source: SourceRef, idPrefix: string): Criterion | null {
  const values = uniq(codes.map((c) => c.hcpc_code_id).filter(Boolean));
  if (!values.length) return null;
  return {
    id: `${idPrefix}_hcpcs_covered`,
    description: `Ordered HCPCS item is covered by ${source.doc_id} (${values.length} codes, e.g. ${values.slice(0, 4).join(", ")})`,
    hard: true,
    check: {
      op: "all",
      of: [
        { op: "present", path: "order.items" },
        { op: "in", path: "order.items[*]", values },
      ],
    },
    requires: ["order.items"],
    gap: {
      missing: "No HCPCS item on the order; add the ordered device code",
      unmet: `Ordered item is not covered under ${source.doc_id}; confirm the correct policy/code`,
    },
    source,
  };
}

/** ICD-10 covered list -> "any ordered dx is in the covered set". */
export function icd10CoveredCriterion(codes: Icd10Row[], source: SourceRef, idPrefix: string): Criterion | null {
  const values = uniq(codes.map((c) => c.icd10_code_id).filter(Boolean));
  if (!values.length) return null;
  return {
    id: `${idPrefix}_icd10_covered`,
    description: `At least one ordered diagnosis is on the ICD-10 covered list of ${source.doc_id} (${values.length} codes)`,
    hard: true,
    check: { op: "in", path: "order.dx[*]", values },
    requires: ["order.dx"],
    gap: {
      missing: "No diagnosis codes on the order; add the supporting ICD-10 code(s)",
      unmet: `None of the ordered diagnoses are on the covered list; verify the dx against ${source.doc_id}`,
    },
    source,
  };
}

/** ICD-10 non-covered list -> exclusion: "no ordered dx is in the non-covered set". */
export function icd10NonCoveredCriterion(codes: Icd10Row[], source: SourceRef, idPrefix: string): Criterion | null {
  const values = uniq(codes.map((c) => c.icd10_code_id).filter(Boolean));
  if (!values.length) return null;
  return {
    id: `${idPrefix}_icd10_noncovered`,
    description: `No ordered diagnosis is on the ICD-10 NON-covered list of ${source.doc_id} (${values.length} codes)`,
    hard: true,
    check: { op: "not", of: { op: "in", path: "order.dx[*]", values } },
    requires: ["order.dx"],
    gap: {
      missing: "No diagnosis codes on the order; add the supporting ICD-10 code(s)",
      unmet: `An ordered diagnosis is explicitly non-covered under ${source.doc_id}`,
    },
    source,
  };
}

/** Required modifiers -> present/in check on order.modifiers (informational by default). */
export function modifierCriterion(mods: ModifierRow[], source: SourceRef, idPrefix: string): Criterion | null {
  const values = uniq(mods.map((m) => m.hcpc_modifier_code_id).filter(Boolean));
  if (!values.length) return null;
  return {
    id: `${idPrefix}_modifiers`,
    description: `Recognized billing modifier present (${values.join(", ")}) per ${source.doc_id}`,
    hard: false, // billing detail; human reviewer can promote to hard
    check: { op: "in", path: "order.modifiers[*]", values },
    requires: ["order.modifiers"],
    gap: { missing: "Add the applicable billing modifier", unmet: "Modifier is not among those recognized by the article" },
    source,
  };
}

// --------------------------------------------------------------- orchestration

export interface IngestResult {
  version: PolicyVersion;
  stats: { hcpcs: number; icd10_covered: number; icd10_noncovered: number; modifiers: number; articles: number[] };
}

/**
 * Ingest one LCD (+ its related articles) into a pending_review PolicyVersion.
 * No LLM. Items in the PolicyKey are derived from the covered HCPCS codes themselves.
 */
export async function ingestLcd(client: CmsClient, opts: IngestOptions): Promise<IngestResult> {
  const payer = opts.payer ?? "medicare";
  const jurisdiction = opts.jurisdiction ?? "national";
  const lcdNum = numericId(opts.lcd);
  const idPrefix = `${opts.category}_L${lcdNum}`;

  const catalog = await client.getLcdCatalogEntry(lcdNum);
  const detail = await client.getLcdDetail(lcdNum).catch(() => null);
  const title = catalog?.title ?? detail?.title ?? `LCD L${lcdNum}`;
  const lcdVersion = catalog?.document_version ?? detail?.lcd_version ?? 0;
  const effective = toISODate(catalog?.effective_date) ?? detail?.effective_date ?? new Date().toISOString().slice(0, 10);

  const lcdSource: SourceRef = {
    issuer: "CMS",
    doc_type: "LCD",
    doc_id: `L${lcdNum}`,
    url: lcdUrl(lcdNum),
    fetched_at: new Date().toISOString(),
    checksum: `version:${lcdVersion}`,
  };

  const criteria: Criterion[] = [];
  const stats = { hcpcs: 0, icd10_covered: 0, icd10_noncovered: 0, modifiers: 0, articles: [] as number[] };

  // HCPCS coverage from the LCD itself.
  const hcpcs = await client.getLcdHcpcCodes(lcdNum);
  stats.hcpcs = hcpcs.length;
  const hc = hcpcsCoverageCriterion(hcpcs, { ...lcdSource, section: "HCPCS Codes" }, idPrefix);
  if (hc) criteria.push(hc);

  // ICD-10 + modifiers from related Billing & Coding article(s).
  const articleIds = await client.getRelatedArticleIds(lcdNum);
  const coveredAll: Icd10Row[] = [];
  const noncoveredAll: Icd10Row[] = [];
  const modsAll: ModifierRow[] = [];
  let primaryArticle: number | undefined;
  for (const aid of articleIds) {
    const [cov, non, mods] = await Promise.all([
      client.getArticleIcd10Covered(aid).catch(() => []),
      client.getArticleIcd10NonCovered(aid).catch(() => []),
      client.getArticleModifiers(aid).catch(() => []),
    ]);
    if (cov.length || non.length || mods.length) {
      stats.articles.push(aid);
      if (primaryArticle === undefined && cov.length) primaryArticle = aid;
    }
    coveredAll.push(...cov);
    noncoveredAll.push(...non);
    modsAll.push(...mods);
  }

  const articleForSource = primaryArticle ?? articleIds[0];
  const articleSource = (section: string): SourceRef => ({
    issuer: "CMS",
    doc_type: "ARTICLE",
    doc_id: articleForSource ? `A${articleForSource}` : `L${lcdNum}`,
    section,
    url: articleForSource ? articleUrl(articleForSource) : lcdUrl(lcdNum),
    fetched_at: new Date().toISOString(),
  });

  const covCrit = icd10CoveredCriterion(coveredAll, articleSource("ICD-10 Codes That Support Medical Necessity"), idPrefix);
  if (covCrit) {
    criteria.push(covCrit);
    stats.icd10_covered = uniqCount(coveredAll.map((c) => c.icd10_code_id));
  }
  const nonCrit = icd10NonCoveredCriterion(noncoveredAll, articleSource("ICD-10 Codes That Do Not Support Medical Necessity"), idPrefix);
  if (nonCrit) {
    criteria.push(nonCrit);
    stats.icd10_noncovered = uniqCount(noncoveredAll.map((c) => c.icd10_code_id));
  }
  const modCrit = modifierCriterion(modsAll, articleSource("Modifiers"), idPrefix);
  if (modCrit) {
    criteria.push(modCrit);
    stats.modifiers = uniqCount(modsAll.map((m) => m.hcpc_modifier_code_id));
  }

  const items = uniq(hcpcs.map((h) => h.hcpc_code_id).filter(Boolean));

  const version: PolicyVersion = {
    version_id: `${payer}-${opts.category}-L${lcdNum}-v${lcdVersion}`,
    key: { payer, category: opts.category, items, jurisdiction },
    status: "pending_review", // never auto-active
    effective_date: effective,
    criteria,
    source: lcdSource,
    created_at: new Date().toISOString(),
    created_by: "cms-ingest",
    notes:
      `Structured ingest of ${title} (LCD L${lcdNum} v${lcdVersion}). ` +
      `No LLM. Clinical thresholds from the narrative are NOT included here — author them in src/packs/${opts.category}.ts (8b).`,
  };

  return { version, stats };
}

function uniqCount(xs: string[]): number {
  return new Set(xs.filter(Boolean)).size;
}
