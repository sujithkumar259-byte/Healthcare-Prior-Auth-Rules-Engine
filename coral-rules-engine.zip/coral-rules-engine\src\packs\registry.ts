// Pack registry — the single place that gathers every authored policy pack.
//
// Every pack now lives as DATA: `src/packs/data/<category>.json` + a row in
// `src/packs/data/_manifest.json`, loaded and DSL-validated by load-data-packs.ts. Every
// pack ships `pending_review` — none is resolvable until a human approves it through the
// review queue. Adding/updating a policy is a data change — no code here changes.

import { PolicyVersion } from "../types.js";
import { loadDataPacks } from "./load-data-packs.js";

/** Every pack, regardless of status. */
export function allPacks(): PolicyVersion[] {
  return loadDataPacks();
}

/** Packs that are already active (resolvable today). */
export function loadActivePacks(): PolicyVersion[] {
  return allPacks().filter((v) => v.status === "active");
}

/** Packs awaiting human approval (status pending_review). */
export function loadPendingPacks(): PolicyVersion[] {
  return allPacks().filter((v) => v.status === "pending_review");
}
