// Test entry point — runs every suite and exits non-zero on any failure.
//   run:  npm test
import { summarize } from "./harness.js";
import { dslTests } from "./dsl.test.js";
import { engineTests } from "./engine.test.js";
import { storeTests } from "./store.test.js";
import { ingestTests } from "./ingest.test.js";
import { packsTests } from "./packs.test.js";

dslTests();
engineTests();
storeTests();
ingestTests();
packsTests();
summarize();
