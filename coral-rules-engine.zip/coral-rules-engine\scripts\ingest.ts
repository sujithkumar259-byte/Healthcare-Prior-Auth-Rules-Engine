// 8a structured ingest — turn an LCD's code tables into a pending_review PolicyVersion.
//
//   npm run ingest -- L33718              (category resolved from seed-catalog.json)
//   npm run ingest -- L33797 home_oxygen  (explicit category)
//   npm run ingest -- L33718 --json       (print the full PolicyVersion JSON)
//
// No LLM. Prints a summary + the generated criteria; with --json, the full version.

import { CmsClient } from "../src/cms-client.js";
import { ingestLcd } from "../src/ingest-structured.js";
import { loadSeedCatalog, findSeed } from "../src/seed-catalog.js";

async function main() {
  const args = process.argv.slice(2).filter((a) => a !== "--");
  const asJson = args.includes("--json");
  const positional = args.filter((a) => !a.startsWith("--"));
  const lcd = positional[0];
  if (!lcd) {
    console.error("usage: npm run ingest -- <LCD id> [category] [--json]");
    process.exit(2);
  }

  const catalog = loadSeedCatalog();
  const seed = findSeed(catalog, lcd);
  const category = positional[1] ?? seed?.category;
  if (!category) {
    console.error(`No category for ${lcd}. Add it to seed-catalog.json or pass one: npm run ingest -- ${lcd} <category>`);
    process.exit(2);
  }

  const client = new CmsClient();
  console.error(`Ingesting ${lcd} as category "${category}" (payer ${catalog.payer}, ${catalog.jurisdiction})...`);
  const { version, stats } = await ingestLcd(client, {
    lcd,
    category,
    payer: catalog.payer,
    jurisdiction: catalog.jurisdiction,
  });

  if (asJson) {
    console.log(JSON.stringify(version, null, 2));
    return;
  }

  console.log(`\nVersion ${version.version_id}  [${version.status}]  effective ${version.effective_date}`);
  console.log(`Key: ${JSON.stringify(version.key)}`);
  console.log(
    `Tables: HCPCS=${stats.hcpcs}  ICD10-covered=${stats.icd10_covered}  ICD10-noncovered=${stats.icd10_noncovered}  modifiers=${stats.modifiers}  (articles: ${stats.articles.join(", ") || "none"})`,
  );
  console.log(`\nGenerated ${version.criteria.length} criteria:`);
  for (const c of version.criteria) {
    console.log(`  - ${c.id}  [${c.hard ? "hard" : "soft"}]  ${c.check.op}`);
    console.log(`      ${c.description}`);
    console.log(`      source: ${c.source.doc_type} ${c.source.doc_id} §${c.source.section ?? "-"}  ${c.source.url}`);
  }
  console.log(`\nNote: ${version.notes}`);
  console.log(`\n(Not active. Approve via the review queue. Clinical thresholds -> author src/packs/${category}.ts)`);
}

main().catch((e) => {
  console.error("ingest failed:", e instanceof Error ? e.message : e);
  process.exit(1);
});
