// Safe, deterministic interpreter for the Check DSL.
//
// HARD CONSTRAINT: this file must never use eval/Function or execute any value coming
// from data. It only ever reads values out of the case and compares them with fixed
// operators. A hostile string in the evidence is data, never code.

import { Case, Check, CmpOp } from "./types.js";

/**
 * Resolve a path to a value.
 *
 *  1. Exact evidence key:  case.evidence["sleep_study.ahi"].value   (the common case).
 *  2. Otherwise a dotted path into the Case object: "order.items", "order.prescriber_npi".
 *
 * A trailing "[*]" is stripped here; array-membership semantics are applied by the
 * caller (the `in` op). This keeps lookup uniform while letting `order.dx[*]` address
 * the dx array.
 */
function resolveValue(c: Case, rawPath: string): unknown {
  const path = stripArrayMarker(rawPath);

  // 1) Flat evidence map keyed by the literal path string.
  const ev = c.evidence[path];
  if (ev !== undefined) return ev.value;

  // 2) Structural fields on the case object (order.*, coverage.*, ...).
  return walkDotted(c as unknown as Record<string, unknown>, path);
}

function stripArrayMarker(path: string): string {
  return path.endsWith("[*]") ? path.slice(0, -3) : path;
}

function isArrayPath(path: string): boolean {
  return path.endsWith("[*]");
}

// Keys that would climb the prototype chain. Blocked so a hostile path string can never
// reach Object.prototype / constructors — defense in depth even though the DSL never
// executes what it reads.
const UNSAFE_SEGMENTS = new Set(["__proto__", "prototype", "constructor"]);

function walkDotted(root: Record<string, unknown>, path: string): unknown {
  let cur: unknown = root;
  for (const seg of path.split(".")) {
    if (cur === null || cur === undefined || typeof cur !== "object") return undefined;
    if (UNSAFE_SEGMENTS.has(seg)) return undefined;
    // Own-property access only; never inherit from the prototype chain.
    if (!Object.prototype.hasOwnProperty.call(cur, seg)) return undefined;
    cur = (cur as Record<string, unknown>)[seg];
  }
  return cur;
}

/**
 * Confidence attached to a path. Only the evidence map carries confidence; structural
 * case fields (order.*, coverage.*) are considered certain (1). Used by the engine to
 * decide abstention. Exported so the engine resolves confidence the same way values
 * are resolved.
 */
export function resolveConfidence(c: Case, rawPath: string): number {
  const ev = c.evidence[stripArrayMarker(rawPath)];
  return ev?.confidence ?? 1;
}

/** True when a required path has a usable (non-null) value, by the same resolution rules. */
export function isPresent(c: Case, rawPath: string): boolean {
  const v = resolveValue(c, rawPath);
  return v !== undefined && v !== null;
}

function compare(a: unknown, op: CmpOp, b: unknown): boolean {
  switch (op) {
    // Relational operators only make sense for same-typed, comparable scalars.
    case ">=":
      return typeof a === typeof b && (a as number) >= (b as number);
    case "<=":
      return typeof a === typeof b && (a as number) <= (b as number);
    case ">":
      return typeof a === typeof b && (a as number) > (b as number);
    case "<":
      return typeof a === typeof b && (a as number) < (b as number);
    // Equality is strict and type-safe; a hostile string never coerces into a match.
    case "==":
      return a === b;
    case "!=":
      return a !== b;
    default:
      return false;
  }
}

/**
 * Evaluate a Check against a case. Returns a plain boolean — "does the evidence satisfy
 * this logic?". Missing/low-confidence handling lives in the engine, not here.
 */
export function evalCheck(c: Case, ck: Check): boolean {
  switch (ck.op) {
    case "present": {
      const v = resolveValue(c, ck.path);
      return v !== undefined && v !== null;
    }
    case "absent": {
      const v = resolveValue(c, ck.path);
      return v === undefined || v === null;
    }
    case "nonEmpty": {
      const v = resolveValue(c, ck.path);
      return Array.isArray(v) ? v.length > 0 : Boolean(v);
    }
    case "cmp":
      return compare(resolveValue(c, ck.path), ck.cmp, ck.value);
    case "in": {
      // Array path "x[*]" => ANY element is in the set (the dx covered-set / anyIn helper).
      if (isArrayPath(ck.path)) {
        const arr = resolveValue(c, ck.path);
        return Array.isArray(arr) && arr.some((el) => ck.values.includes(el as string | number));
      }
      const v = resolveValue(c, ck.path);
      return ck.values.includes(v as string | number);
    }
    case "ratio": {
      const n = resolveValue(c, ck.num);
      const d = resolveValue(c, ck.den);
      if (typeof n !== "number" || typeof d !== "number" || Number.isNaN(n) || Number.isNaN(d)) return false;
      if (d === 0) return false;
      if (ck.minDen != null && d < ck.minDen) return false;
      return compare(n / d, ck.cmp, ck.value);
    }
    case "all":
      return ck.of.every((x) => evalCheck(c, x));
    case "any":
      return ck.of.some((x) => evalCheck(c, x));
    case "not":
      return !evalCheck(c, ck.of);
    default: {
      // Exhaustiveness guard: an unknown op is never silently "true".
      const _never: never = ck;
      void _never;
      return false;
    }
  }
}
