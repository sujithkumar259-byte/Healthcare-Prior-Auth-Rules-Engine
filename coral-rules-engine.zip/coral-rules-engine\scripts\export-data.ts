// export-data — dump every loaded pack to a single JSON for the explorer/UI.
//   npm run export
import { writeFileSync } from "node:fs";
import { allPacks } from "../src/packs/registry.js";

const packs = allPacks().map((v) => ({
  version_id: v.version_id,
  payer: v.key.payer,
  category: v.key.category,
  jurisdiction: v.key.jurisdiction ?? "",
  status: v.status,
  effective_date: v.effective_date,
  items: v.key.items,
  source: v.source,
  notes: v.notes ?? "",
  criteria: v.criteria.map((c) => ({
    id: c.id,
    description: c.description,
    phase: c.phase ?? "",
    hard: c.hard,
    check: c.check,
    requires: c.requires,
    gap: c.gap,
    source: c.source,
  })),
}));

const totals = {
  packs: packs.length,
  payers: [...new Set(packs.map((p) => p.payer))],
  criteria: packs.reduce((n, p) => n + p.criteria.length, 0),
  active: packs.filter((p) => p.status === "active").length,
  pending: packs.filter((p) => p.status === "pending_review").length,
};

const out = { generated_note: "All packs except the verified PAP pack are pending_review.", totals, packs };
writeFileSync("explorer-data.json", JSON.stringify(out));
console.log(`exported ${packs.length} packs / ${totals.criteria} criteria -> explorer-data.json`);
