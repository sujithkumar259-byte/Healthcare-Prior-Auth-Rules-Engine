// Domain model for the prior-authorization rules engine.
//
// The central design rule: RULES ARE DATA. A criterion's logic is a serializable
// `Check` object, versioned and effective-dated. Adding a category or changing a
// policy is a data change, never an engine-code change. Every criterion carries a
// `source` so any verdict can be traced back to the primary document.

export type ISODate = string; // "YYYY-MM-DD" or full ISO-8601 timestamp

/**
 * Provenance for a criterion. No criterion exists without one — this is what makes
 * every verdict auditable back to a primary source (CMS NCD/LCD/Article or payer PDF).
 */
export interface SourceRef {
  issuer: string; // "CMS", "Aetna"
  doc_type: "NCD" | "LCD" | "ARTICLE" | "PAYER_POLICY";
  doc_id: string; // "240.4", "L33718"
  section?: string;
  url: string;
  fetched_at?: ISODate;
  checksum?: string; // hash of the source -> change detection on refresh
}

/**
 * Serializable check DSL. This is the ONLY logic a criterion may express.
 * The interpreter (dsl.ts) walks these objects; it never executes data as code.
 *
 * Path conventions for `path`/`num`/`den`:
 *   - A path is first resolved against `case.evidence[path].value` (the normal case).
 *   - If the evidence map has no such key, it is resolved as a dotted path against the
 *     Case object itself, so structural fields like "order.items" and
 *     "order.prescriber_npi" are addressable too.
 *   - A trailing "[*]" marks an array-valued path for membership semantics. With the
 *     `in` op it means "ANY element is in `values`" (the dx-list / anyIn helper from
 *     spec 8a). Example: { op:"in", path:"order.dx[*]", values:[...covered ICD-10...] }.
 */
export type Check =
  | { op: "present"; path: string }
  | { op: "absent"; path: string }
  | { op: "nonEmpty"; path: string }
  | { op: "cmp"; path: string; cmp: CmpOp; value: number | string | boolean }
  | { op: "in"; path: string; values: (string | number)[] }
  | { op: "ratio"; num: string; den: string; cmp: RatioCmpOp; value: number; minDen?: number }
  | { op: "all"; of: Check[] }
  | { op: "any"; of: Check[] }
  | { op: "not"; of: Check };

export type CmpOp = ">=" | "<=" | ">" | "<" | "==" | "!=";
export type RatioCmpOp = ">=" | "<=" | ">" | "<";

export interface Criterion {
  id: string;
  description: string;
  phase?: string; // category-defined, e.g. "initial" | "continued". Unset = applies to all phases.
  hard: boolean; // hard = required for approval; soft = informational
  check: Check;
  requires: string[]; // evidence paths that must be present (non-null) to evaluate the check
  gap: Partial<Record<"missing" | "unmet" | "uncertain", string>>; // human action per non-satisfied status
  source: SourceRef;
}

export interface PolicyKey {
  payer: string; // "medicare", "aetna"
  category: string; // "dme_pap", "home_oxygen", ...
  items: string[]; // HCPCS codes this policy governs; [] = matches any item
  jurisdiction?: string; // MAC / state / "national"; unset = matches any
}

export type VersionStatus = "draft" | "pending_review" | "active" | "retired";

/**
 * Versioning is append-only. Updates create new PolicyVersions; prior versions are
 * retired with a date, never overwritten — so a historical case evaluates against the
 * rules that applied on its service date.
 */
export interface PolicyVersion {
  version_id: string;
  key: PolicyKey;
  status: VersionStatus;
  effective_date: ISODate;
  retirement_date?: ISODate;
  criteria: Criterion[];
  source: SourceRef;
  created_at: ISODate;
  created_by: string; // "cms-sync", "pack:pap", reviewer id, ...
  notes?: string;
}

export interface EvidenceField {
  value: any;
  doc_id?: string;
  page?: number;
  confidence?: number; // [0,1]; absent => treated as 1 (fully certain)
}

/**
 * A case is already-extracted input (no PHI handling, no extraction in v1). Evidence is
 * a flat map keyed by the same paths the checks reference, so a new category needs new
 * data, not new code.
 */
export interface Case {
  case_id: string;
  service_date: ISODate; // selects the policy version in force
  category: string;
  phase?: string;
  coverage: { payer: string; plan?: string; member_id?: string; jurisdiction?: string };
  order: { items: string[]; dx?: string[]; prescriber_npi?: string };
  evidence: Record<string, EvidenceField>;
}

export type Status = "satisfied" | "missing" | "unmet" | "uncertain";

export interface CriterionResult {
  criterion_id: string;
  description: string;
  status: Status;
  confidence: number | null;
  gap_action?: string;
  source: SourceRef;
}

export interface Verdict {
  case_id: string;
  policy_version_id: string | null;
  results: CriterionResult[];
  verdict: "submit_ready" | "needs_info" | "abstain" | "no_policy";
}
