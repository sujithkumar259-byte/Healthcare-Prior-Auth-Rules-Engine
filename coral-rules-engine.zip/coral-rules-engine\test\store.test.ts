// Acceptance 2: resolve picks the version effective on the service date and ignores
// retired ones; unmatched payer/category -> no_policy.
// Acceptance 5: a pending_review version is never resolved; only approve activates it
// and retires the prior active version of the same key.
import { test, eq, ok, section } from "./harness.js";
import { InMemoryPolicyStore, ReviewQueue } from "../src/store.js";
import { Case, PolicyVersion, SourceRef } from "../src/types.js";

const SRC: SourceRef = { issuer: "CMS", doc_type: "LCD", doc_id: "L33718", url: "https://x" };

const version = (over: Partial<PolicyVersion>): PolicyVersion => ({
  version_id: "v",
  key: { payer: "medicare", category: "dme_pap", items: ["E0601"], jurisdiction: "national" },
  status: "active",
  effective_date: "2024-01-01",
  criteria: [],
  source: SRC,
  created_at: "2024-01-01T00:00:00Z",
  created_by: "test",
  ...over,
});

const caseOn = (service_date: string): Case => ({
  case_id: "C",
  service_date,
  category: "dme_pap",
  coverage: { payer: "medicare", jurisdiction: "national" },
  order: { items: ["E0601"] },
  evidence: {},
});

export function storeTests(): void {
  section("Store.resolve (Acceptance 2)");

  test("resolves latest effective_date <= service_date", () => {
    const store = new InMemoryPolicyStore();
    store.upsert(version({ version_id: "v2023", effective_date: "2023-01-01" }));
    store.upsert(version({ version_id: "v2025", effective_date: "2025-01-01" }));
    eq(store.resolve(caseOn("2025-06-01"))?.version_id, "v2025");
    eq(store.resolve(caseOn("2024-06-01"))?.version_id, "v2023");
    eq(store.resolve(caseOn("2022-06-01")), null, "before any effective date");
  });

  test("ignores retired versions on the service date", () => {
    const store = new InMemoryPolicyStore();
    store.upsert(version({ version_id: "old", effective_date: "2023-01-01", status: "retired", retirement_date: "2025-01-01" }));
    store.upsert(version({ version_id: "new", effective_date: "2025-01-01" }));
    // A 2024 case still sees the old rules (retired_date > service_date) only if old were active;
    // here old is retired, so a 2026 case must resolve "new".
    eq(store.resolve(caseOn("2026-01-01"))?.version_id, "new");
  });

  test("retirement_date boundary: retired version covers dates before its retirement", () => {
    const store = new InMemoryPolicyStore();
    // Simulate a historical query: an active version that was later retired.
    const v = version({ version_id: "hist", effective_date: "2020-01-01", status: "active" });
    store.upsert(v);
    // case before retirement resolves it; after, it doesn't.
    eq(store.resolve(caseOn("2021-01-01"))?.version_id, "hist");
  });

  test("unmatched payer/category -> no_policy (null)", () => {
    const store = new InMemoryPolicyStore();
    store.upsert(version({}));
    const wrongPayer: Case = { ...caseOn("2025-01-01"), coverage: { payer: "aetna" } };
    eq(store.resolve(wrongPayer), null);
    const wrongCat: Case = { ...caseOn("2025-01-01"), category: "home_oxygen" };
    eq(store.resolve(wrongCat), null);
  });

  test("item overlap: empty policy items matches any order", () => {
    const store = new InMemoryPolicyStore();
    store.upsert(version({ version_id: "anyitem", key: { payer: "medicare", category: "dme_pap", items: [], jurisdiction: "national" } }));
    const other: Case = { ...caseOn("2025-01-01"), order: { items: ["E9999"] } };
    eq(store.resolve(other)?.version_id, "anyitem");
  });

  test("jurisdiction mismatch excludes", () => {
    const store = new InMemoryPolicyStore();
    store.upsert(version({ key: { payer: "medicare", category: "dme_pap", items: ["E0601"], jurisdiction: "JD" } }));
    const natl: Case = { ...caseOn("2025-01-01"), coverage: { payer: "medicare", jurisdiction: "national" } };
    eq(store.resolve(natl), null, "JD policy should not match national case");
  });

  section("Review gate (Acceptance 5)");

  test("pending_review is never resolved", () => {
    const store = new InMemoryPolicyStore();
    store.upsert(version({ version_id: "pend", status: "pending_review" }));
    eq(store.resolve(caseOn("2025-01-01")), null);
  });

  test("approve activates and retires the prior active of the same key", () => {
    const store = new InMemoryPolicyStore();
    const review = new ReviewQueue(store);
    store.upsert(version({ version_id: "v1", effective_date: "2024-01-01", status: "active" }));
    store.upsert(version({ version_id: "v2", effective_date: "2026-01-01", status: "pending_review" }));

    eq(store.resolve(caseOn("2026-06-01"))?.version_id, "v1", "before approval, v1 still active");
    ok(review.list().some((v) => v.version_id === "v2"), "v2 pending");

    review.approve("v2", "sujith");
    eq(store.get("v2")?.status, "active");
    eq(store.get("v1")?.status, "retired");
    eq(store.get("v1")?.retirement_date, "2026-01-01", "prior retired at new effective date");
    eq(store.resolve(caseOn("2026-06-01"))?.version_id, "v2", "after approval, v2 resolves");
    // historical case before v2's effective date still resolves the (now retired) v1
    eq(store.resolve(caseOn("2025-06-01"))?.version_id, "v1", "history preserved");
  });

  test("reject sends version back to draft (not resolvable)", () => {
    const store = new InMemoryPolicyStore();
    const review = new ReviewQueue(store);
    store.upsert(version({ version_id: "vp", status: "pending_review" }));
    review.reject("vp");
    eq(store.get("vp")?.status, "draft");
    eq(store.resolve(caseOn("2025-01-01")), null);
  });
}
