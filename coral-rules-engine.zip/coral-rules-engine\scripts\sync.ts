// sync — pull the live LCD catalog, detect changed/new tracked policies, structured-ingest
// them into pending_review versions, and report what's now awaiting review.
//
//   npm run sync                  (check all tracked LCDs; ingest changed ones)
//   npm run sync -- --include-verified   (also re-ingest the verified PAP pack to diff)
//   npm run sync -- --approve-all REVIEWER  (DEV ONLY: auto-approve everything queued)
//
// Nothing goes active automatically; approval is a human step (ReviewQueue.approve).

import { CmsClient } from "../src/cms-client.js";
import { InMemoryPolicyStore, ReviewQueue } from "../src/store.js";
import { loadSeedCatalog } from "../src/seed-catalog.js";
import { sync } from "../src/refresh.js";
import { loadActivePacks } from "../src/packs/registry.js";

async function main() {
  const args = process.argv.slice(2).filter((a) => a !== "--");
  const includeVerified = args.includes("--include-verified");
  const approveIdx = args.indexOf("--approve-all");

  const store = new InMemoryPolicyStore();
  // Seed the store with whatever packs already exist so change detection has a baseline.
  loadActivePacks().forEach((v) => store.upsert(v));

  const review = new ReviewQueue(store);
  const catalog = loadSeedCatalog();
  const client = new CmsClient();

  console.error(`Syncing ${catalog.policies.length} tracked policies against the live CMS catalog...`);
  const summary = await sync({ client, store, review, catalog }, { includeVerified });

  console.log(`\nChecked ${summary.checked}, queued ${summary.queued} for review.\n`);
  for (const c of summary.changes) {
    const tag = c.action.toUpperCase().padEnd(9);
    const ver = `live v${c.currentVersion ?? "?"} / known v${c.knownVersion ?? "-"}`;
    const extra = c.version_id ? `  -> ${c.version_id} (${c.criteria} criteria)` : c.reason ? `  (${c.reason})` : "";
    console.log(`  ${tag} ${c.lcd} [${c.category}]  ${ver}${extra}`);
  }

  const pending = review.list();
  if (pending.length) {
    console.log(`\n${pending.length} version(s) awaiting review:`);
    for (const v of pending) console.log(`  - ${v.version_id}  (${v.criteria.length} criteria, effective ${v.effective_date})`);
  }

  if (approveIdx >= 0) {
    const reviewer = args[approveIdx + 1] ?? "dev";
    console.log(`\n[--approve-all] activating ${pending.length} version(s) as "${reviewer}"...`);
    for (const v of pending) review.approve(v.version_id, reviewer);
    console.log("done.");
  } else if (pending.length) {
    console.log(`\nApprove with the review queue (ReviewQueue.approve) — nothing is active until then.`);
  }
}

main().catch((e) => {
  console.error("sync failed:", e instanceof Error ? e.message : e);
  process.exit(1);
});
