// coverage — summarize how many Medicare-PA categories the engine now covers.
//   npm run coverage
import { allPacks, loadActivePacks, loadPendingPacks } from "../src/packs/registry.js";
import { dataPackErrors } from "../src/packs/load-data-packs.js";

const packs = allPacks();
let hard = 0;
let soft = 0;
let needsHuman = 0;
for (const p of packs) {
  for (const c of p.criteria) (c.hard ? hard++ : soft++);
  needsHuman += (p.notes?.match(/(\d+) requirement\(s\) could not be expressed/)?.[1] ? Number(RegExp.$1) : 0);
}

console.log("Medicare Prior-Auth Rules Engine — coverage\n");
console.log(`Categories (policy versions): ${packs.length}`);
console.log(`  active (approved)          : ${loadActivePacks().length}`);
console.log(`  pending_review             : ${loadPendingPacks().length}`);
console.log(`Total criteria               : ${hard + soft}  (hard ${hard}, soft ${soft})`);
console.log(`Data-pack load errors        : ${dataPackErrors.length ? dataPackErrors.join("; ") : "none"}`);

console.log(`\nPer category (criteria | status):`);
for (const p of [...packs].sort((a, b) => a.key.category.localeCompare(b.key.category))) {
  const flag = p.status === "active" ? "ACTIVE " : "pending";
  console.log(`  ${flag}  ${p.key.category.padEnd(52)} ${String(p.criteria.length).padStart(3)}  ${p.source.doc_id}`);
}

// Integrity: every criterion sourced.
const unsourced = packs.flatMap((p) => p.criteria.filter((c) => !c.source.doc_id || !c.source.url.startsWith("http")).map((c) => `${p.key.category}/${c.id}`));
console.log(`\nUnsourced criteria: ${unsourced.length === 0 ? "none (all traceable)" : unsourced.join(", ")}`);
